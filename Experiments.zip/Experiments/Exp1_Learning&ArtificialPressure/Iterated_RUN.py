#! /usr/bin/env python

#if __name__=='__main__':

from psychopy import core, visual, gui, event
import random
from Iterated_module import *
import glob
from xlrd import open_workbook


#reclute participant's ID
info = {"Chain":'',"Participant's ID":''}
infoDlg = gui.DlgFromDict(dictionary=info, title='TestExperiment', fixed=['ExpVersion'])
if infoDlg.OK:
    print info
else: print 'User Cancelled'


myWin = visual.Window((1280.0,800.0),color='white', allowGUI=False,
            monitor='testMonitor', units ='deg', screen=0, fullscr=True)
            
            

myWin.setMouseVisible(False)


#FIRST PART
message1 = visual.TextStim(myWin, color='black', units='norm',pos=[0,0],text='In this experiment you will learn an alien language.')
message2 = visual.TextStim(myWin, color='black',units='norm',pos=[0,0], text="The task is divided into two parts.")
message3 = visual.TextStim(myWin, color='black', units='norm',pos=[0,0],text='In the first part, you will be trained on an alien language.')
message4= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='In the second part, we will test you to see how well you have learned the language.')
message5= visual.TextStim(myWin, color='black', units='norm', pos=[0,0.0], text='In the training phase, you will be shown different scenes with their corresponding descriptions displayed in text on the screen.')
message6= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Sometimes you will be asked to retype the description, please retype it and then press return to confirm.')
message7= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Other times you will be asked to recognise the scene you were just shown by choosing between two scenes, please press the key indicated under the scene to select.')
message8= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='After the training phase there will be a testing phase. In the testing phase you will just be presented with the scene for 5s and then you will be asked to type the description. ')
message9= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Hit return when you are ready to begin.')
next_page=visual.ImageStim(myWin, image='/Users/pplsuser/Desktop/All_frames/return_key.png', units='norm', size=[0.2,0.2],pos=[0.7,-0.6],flipHoriz=False,flipVert=False,autoLog=True)
next_tag= visual.TextStim(myWin, color='black', units='norm', pos=[0.55,-0.6], text='Next')
message1.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message2.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message3.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message4.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message5.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message6.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message7.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message8.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()
message9.draw()
next_page.draw()
next_tag.draw()
myWin.flip()
event.waitKeys()

ID=info["Participant's ID"]
ID_minus_one= int(float(ID))-1
ID_iterated_string=str(ID_minus_one)
chain= int(info["Chain"])
append_to_file('TRAINING', ID,chain)

list_task_type=['retyping', 'retyping', 'clicking', 'retyping', 'clicking', 'retyping', 'clicking', 'clicking', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'clicking', 'retyping', 'retyping', 'retyping', 'retyping', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'clicking', 'clicking', 'retyping', 'retyping', 'retyping', 'retyping', 'retyping', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'retyping', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'retyping', 'retyping', 'retyping', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'retyping', 'clicking', 'clicking', 'retyping', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'retyping', 'clicking', 'retyping', 'clicking', 'retyping', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'clicking', 'clicking', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'retyping', 'clicking', 'clicking', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'clicking', 'clicking', 'retyping', 'retyping', 'clicking', 'retyping', 'clicking', 'retyping', 'retyping', 'retyping', 'clicking', 'retyping']

#list of random names holistic system
#hol_tags=['pacokaya', 'biwefavoke', 'zorichuru', 'cholobewuyalizopi', 'kunoguko', 'biyuchuvevo', 'niwehiyi', 'kubicochenowomuhi', 'desemase', 'chayibe', 'safatakevute', 'wovihibimofuvo', 'churegugubihemame', 'cikivocuseba', 'wuriricikodewe', 'bunuchemefodeto', 'ramivacofe', 'tacofoyayoka', 'konosutibucede', 'wirayepichibihuwu', 'feviwo', 'zutefumowapama', 'gerisozechodepipa', 'yubimo', 'cogokolu', 'chachenichihivawu', 'chiwogumuwope', 'chedike', 'yemehulayike', 'zutidafusa', 'zewoyorulochaye', 'hutami', 'gavitazabu', 'dadosu', 'mezodanukesehu', 'buzarecireme', 'kitinechuhopiholu', 'lomatipu', 'zudichowevepavoci', 'vezachi', 'pabovewedipedise', 'huhoholalo', 'yupuzisadotihe', 'canipulufuviyona', 'yatanage', 'wagarecho', 'fichawa', 'wihesame', 'rilegiwepucakefo', 'hechatuna', 'futororodukumidi', 'fiwuharetiwana', 'chavache', 'wamuhehi', 'sehapehuloyuda', 'tabubavibuwitepu', 'borayoco', 'codinobivo', 'rofacepofevasu', 'chavafiholuba', 'cubidahahiye', 'mawiliciselu', 'coyiyamo', 'focohulacha', 'fadesezizo', 'civumotagoki', 'tazemedecechi', 'musuzihihe', 'catudera', 'necakozozizufu', 'nizugetirupa', 'yokuze', 'tihohibecusahera', 'bofechumafogu', 'dasepasamoyegize', 'viyudeda', 'relalachofekopi', 'dirovomasina', 'yuyoheruzachapuwo', 'hoyesocheyurunini']
#function to break strings
def insert_spaces(hol_string, list_breakPoint):
   str_random_spaces = []
   noOfBreakPoints = len(list_breakPoint)
   for breakPt in range(noOfBreakPoints):
       for index in list_breakPoint:            
               str_random_spaces.append(hol_string[:index])
               hol_string = hol_string[index:]
       break
   return ' '.join(str_random_spaces).strip(' ')
#hol_tags_spaces=['pa cokaya', 'biwefa voke', 'zoric huru', 'cholo bewuyalizopi', 'kuno guko', 'biyuc huvevo', 'niwe hiyi', 'kubic oche nowomu hi', 'de sema se', 'chayi be', 'sa fata ke  vute', 'wo vihi bimo fuvo', 'chure gugubi hemame', 'cikivo cuseba', 'wuri riciko dewe', 'bunuc hemefodeto', 'ra mi vaco fe', 'ta co foya yo ka', 'ko nosu ti bu cede', 'wiray epichi bihuwu', 'feviwo', 'zu tefu mowapa ma', 'geris ozechodepipa', 'yubimo', 'co goko lu', 'chach enichihivawu', 'chiwo gumuwope', 'chedi ke', 'ye mehu la yike', 'zutida fusa', 'zewoy orulochaye', 'hu tami', 'gavi taza bu', 'dado su', 'mezoda nukese hu', 'bu za re ci reme', 'kitin echu hopiholu', 'lomati pu', 'zudic howe vepa voci', 'vezac hi', 'pa bove ve dipedise', 'huhoho lalo', 'yupu zisa do tihe', 'ca nipu lufuvi yo na', 'yatana ge', 'wagar echo', 'ficha wa', 'wihesa me', 'ri legiwe pucake fo', 'hecha buna', 'fu to ro rodu kumidi', 'fiwuha reti wana', 'chava che', 'wamu hehi', 'seha pehulo yu da', 'tabuba vi bu wite pu', 'borayo co', 'co dinobi vo', 'roface pofe va su', 'chava fiholuba', 'cu bi dahahi ye', 'ma wilici selu', 'coyiya mo', 'focoh ulacha', 'fa dese zizo', 'ci vu mo ta goki', 'tazem edecechi', 'musu zihihe', 'catude ra', 'ne cako zozizu fu', 'ni zu getiru pa', 'yokuze', 'tiho hi be cu sahera', 'bofec humafogu', 'dase pasa mo yegize', 'vi yude da', 'relal achofekopi', 'di ro voma sina', 'yuyoh eruzachapuwo', 'hoyes ocheyurunini']
iterated_tags_file=open_workbook('Iterated_lists_sentences_00%s.xls'%ID_iterated_string)
hol_tags_spaces=[]
for i in range(80):
    string_tag=iterated_tags_file.sheets()[chain].cell_value(i,0)
    hol_tags_spaces.append(string_tag.strip())
hol_tags_spaces_with_index=zip(hol_tags_spaces,range(80))
#list(itertools.product(*a))
list_intransitive_combinations_all16=[('DeepPink', 'raisedCos', 'singular', 'bounce', 'perfective'), ('DeepPink', 'raisedCos', 'singular', 'bounce', 'continuous'), ('DeepPink', 'raisedCos', 'singular', 'slide', 'perfective'), ('DeepPink', 'raisedCos', 'singular', 'slide', 'continuous'), ('DeepPink', 'raisedCos', 'plural', 'bounce', 'perfective'), ('DeepPink', 'raisedCos', 'plural', 'bounce', 'continuous'), ('DeepPink', 'raisedCos', 'plural', 'slide', 'perfective'), ('DeepPink', 'raisedCos', 'plural', 'slide', 'continuous'), ('DeepPink', 'None', 'singular', 'bounce', 'perfective'), ('DeepPink', 'None', 'singular', 'bounce', 'continuous'), ('DeepPink', 'None', 'singular', 'slide', 'perfective'), ('DeepPink', 'None', 'singular', 'slide', 'continuous'), ('DeepPink', 'None', 'plural', 'bounce', 'perfective'), ('DeepPink', 'None', 'plural', 'bounce', 'continuous'), ('DeepPink', 'None', 'plural', 'slide', 'perfective'), ('DeepPink', 'None', 'plural', 'slide', 'continuous')]
list_transitive_combinations_all64=[('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'slide', 'continuous')]
#indexes_int=['/Users/pplsuser/Desktop/All_frames/00%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/01%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/02%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/03%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/04%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/05%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/06%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/07%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/08%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/09%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/010%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/011%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/012%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/013%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/014%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/015%s*.png'%starting_pos] 
#indexes_trans=['/Users/pplsuser/Desktop/All_frames/0%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/1%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/2%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/3%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/4%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/5%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/6%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/7%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/8%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/9%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/10%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/11%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/12%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/13%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/14%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/15%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/16%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/17%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/18%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/19%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/20%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/21%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/22%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/23%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/24%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/25%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/26%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/27%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/28%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/29%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/30%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/31%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/32%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/33%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/34%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/35%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/36%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/37%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/38%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/39%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/40%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/41%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/42%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/43%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/44%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/45%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/46%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/47%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/48%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/49%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/50%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/51%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/52%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/53%s*.png'%starting_pos,'/Users/pplsuser/Desktop/All_frames/54%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/55%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/56%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/57%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/58%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/59%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/60%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/61%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/62%s*.png'%starting_pos, '/Users/pplsuser/Desktop/All_frames/63%s*.png'%starting_pos]
indexes_int_left=['/Users/pplsuser/Desktop/All_frames/00left*.png', '/Users/pplsuser/Desktop/All_frames/01left*.png', '/Users/pplsuser/Desktop/All_frames/02left*.png', '/Users/pplsuser/Desktop/All_frames/03left*.png', '/Users/pplsuser/Desktop/All_frames/04left*.png', '/Users/pplsuser/Desktop/All_frames/05left*.png', '/Users/pplsuser/Desktop/All_frames/06left*.png', '/Users/pplsuser/Desktop/All_frames/07left*.png', '/Users/pplsuser/Desktop/All_frames/08left*.png', '/Users/pplsuser/Desktop/All_frames/09left*.png', '/Users/pplsuser/Desktop/All_frames/010left*.png', '/Users/pplsuser/Desktop/All_frames/011left*.png', '/Users/pplsuser/Desktop/All_frames/012left*.png', '/Users/pplsuser/Desktop/All_frames/013left*.png', '/Users/pplsuser/Desktop/All_frames/014left*.png', '/Users/pplsuser/Desktop/All_frames/015left*.png']
indexes_int_right=['/Users/pplsuser/Desktop/All_frames/00right*.png', '/Users/pplsuser/Desktop/All_frames/01right*.png', '/Users/pplsuser/Desktop/All_frames/02right*.png', '/Users/pplsuser/Desktop/All_frames/03right*.png', '/Users/pplsuser/Desktop/All_frames/04right*.png', '/Users/pplsuser/Desktop/All_frames/05right*.png', '/Users/pplsuser/Desktop/All_frames/06right*.png', '/Users/pplsuser/Desktop/All_frames/07right*.png', '/Users/pplsuser/Desktop/All_frames/08right*.png', '/Users/pplsuser/Desktop/All_frames/09right*.png', '/Users/pplsuser/Desktop/All_frames/010right*.png', '/Users/pplsuser/Desktop/All_frames/011right*.png', '/Users/pplsuser/Desktop/All_frames/012right*.png', '/Users/pplsuser/Desktop/All_frames/013right*.png', '/Users/pplsuser/Desktop/All_frames/014right*.png', '/Users/pplsuser/Desktop/All_frames/015right*.png']
list_intransitive_combinations_zip_left=zip(list_intransitive_combinations_all16,indexes_int_left)
list_intransitive_combinations_zip_right=zip(list_intransitive_combinations_all16,indexes_int_right)
indexes_trans_right=['/Users/pplsuser/Desktop/All_frames/0right*.png', '/Users/pplsuser/Desktop/All_frames/1right*.png', '/Users/pplsuser/Desktop/All_frames/2right*.png', '/Users/pplsuser/Desktop/All_frames/3right*.png', '/Users/pplsuser/Desktop/All_frames/4right*.png', '/Users/pplsuser/Desktop/All_frames/5right*.png', '/Users/pplsuser/Desktop/All_frames/6right*.png', '/Users/pplsuser/Desktop/All_frames/7right*.png', '/Users/pplsuser/Desktop/All_frames/8right*.png', '/Users/pplsuser/Desktop/All_frames/9right*.png', '/Users/pplsuser/Desktop/All_frames/10right*.png', '/Users/pplsuser/Desktop/All_frames/11right*.png', '/Users/pplsuser/Desktop/All_frames/12right*.png', '/Users/pplsuser/Desktop/All_frames/13right*.png', '/Users/pplsuser/Desktop/All_frames/14right*.png', '/Users/pplsuser/Desktop/All_frames/15right*.png', '/Users/pplsuser/Desktop/All_frames/16right*.png', '/Users/pplsuser/Desktop/All_frames/17right*.png', '/Users/pplsuser/Desktop/All_frames/18right*.png', '/Users/pplsuser/Desktop/All_frames/19right*.png', '/Users/pplsuser/Desktop/All_frames/20right*.png', '/Users/pplsuser/Desktop/All_frames/21right*.png', '/Users/pplsuser/Desktop/All_frames/22right*.png', '/Users/pplsuser/Desktop/All_frames/23right*.png', '/Users/pplsuser/Desktop/All_frames/24right*.png', '/Users/pplsuser/Desktop/All_frames/25right*.png', '/Users/pplsuser/Desktop/All_frames/26right*.png', '/Users/pplsuser/Desktop/All_frames/27right*.png', '/Users/pplsuser/Desktop/All_frames/28right*.png', '/Users/pplsuser/Desktop/All_frames/29right*.png', '/Users/pplsuser/Desktop/All_frames/30right*.png', '/Users/pplsuser/Desktop/All_frames/31right*.png', '/Users/pplsuser/Desktop/All_frames/32right*.png', '/Users/pplsuser/Desktop/All_frames/33right*.png', '/Users/pplsuser/Desktop/All_frames/34right*.png', '/Users/pplsuser/Desktop/All_frames/35right*.png', '/Users/pplsuser/Desktop/All_frames/36right*.png', '/Users/pplsuser/Desktop/All_frames/37right*.png', '/Users/pplsuser/Desktop/All_frames/38right*.png', '/Users/pplsuser/Desktop/All_frames/39right*.png', '/Users/pplsuser/Desktop/All_frames/40right*.png', '/Users/pplsuser/Desktop/All_frames/41right*.png', '/Users/pplsuser/Desktop/All_frames/42right*.png', '/Users/pplsuser/Desktop/All_frames/43right*.png', '/Users/pplsuser/Desktop/All_frames/44right*.png', '/Users/pplsuser/Desktop/All_frames/45right*.png', '/Users/pplsuser/Desktop/All_frames/46right*.png', '/Users/pplsuser/Desktop/All_frames/47right*.png', '/Users/pplsuser/Desktop/All_frames/48right*.png', '/Users/pplsuser/Desktop/All_frames/49right*.png', '/Users/pplsuser/Desktop/All_frames/50right*.png', '/Users/pplsuser/Desktop/All_frames/51right*.png', '/Users/pplsuser/Desktop/All_frames/52right*.png', '/Users/pplsuser/Desktop/All_frames/53right*.png', '/Users/pplsuser/Desktop/All_frames/54right*.png', '/Users/pplsuser/Desktop/All_frames/55right*.png', '/Users/pplsuser/Desktop/All_frames/56right*.png', '/Users/pplsuser/Desktop/All_frames/57right*.png', '/Users/pplsuser/Desktop/All_frames/58right*.png', '/Users/pplsuser/Desktop/All_frames/59right*.png', '/Users/pplsuser/Desktop/All_frames/60right*.png', '/Users/pplsuser/Desktop/All_frames/61right*.png', '/Users/pplsuser/Desktop/All_frames/62right*.png', '/Users/pplsuser/Desktop/All_frames/63right*.png']
indexes_trans_left=['/Users/pplsuser/Desktop/All_frames/0left*.png', '/Users/pplsuser/Desktop/All_frames/1left*.png', '/Users/pplsuser/Desktop/All_frames/2left*.png', '/Users/pplsuser/Desktop/All_frames/3left*.png', '/Users/pplsuser/Desktop/All_frames/4left*.png', '/Users/pplsuser/Desktop/All_frames/5left*.png', '/Users/pplsuser/Desktop/All_frames/6left*.png', '/Users/pplsuser/Desktop/All_frames/7left*.png', '/Users/pplsuser/Desktop/All_frames/8left*.png', '/Users/pplsuser/Desktop/All_frames/9left*.png', '/Users/pplsuser/Desktop/All_frames/10left*.png', '/Users/pplsuser/Desktop/All_frames/11left*.png', '/Users/pplsuser/Desktop/All_frames/12left*.png', '/Users/pplsuser/Desktop/All_frames/13left*.png', '/Users/pplsuser/Desktop/All_frames/14left*.png', '/Users/pplsuser/Desktop/All_frames/15left*.png', '/Users/pplsuser/Desktop/All_frames/16left*.png', '/Users/pplsuser/Desktop/All_frames/17left*.png', '/Users/pplsuser/Desktop/All_frames/18left*.png', '/Users/pplsuser/Desktop/All_frames/19left*.png', '/Users/pplsuser/Desktop/All_frames/20left*.png', '/Users/pplsuser/Desktop/All_frames/21left*.png', '/Users/pplsuser/Desktop/All_frames/22left*.png', '/Users/pplsuser/Desktop/All_frames/23left*.png', '/Users/pplsuser/Desktop/All_frames/24left*.png', '/Users/pplsuser/Desktop/All_frames/25left*.png', '/Users/pplsuser/Desktop/All_frames/26left*.png', '/Users/pplsuser/Desktop/All_frames/27left*.png', '/Users/pplsuser/Desktop/All_frames/28left*.png', '/Users/pplsuser/Desktop/All_frames/29left*.png', '/Users/pplsuser/Desktop/All_frames/30left*.png', '/Users/pplsuser/Desktop/All_frames/31left*.png', '/Users/pplsuser/Desktop/All_frames/32left*.png', '/Users/pplsuser/Desktop/All_frames/33left*.png', '/Users/pplsuser/Desktop/All_frames/34left*.png', '/Users/pplsuser/Desktop/All_frames/35left*.png', '/Users/pplsuser/Desktop/All_frames/36left*.png', '/Users/pplsuser/Desktop/All_frames/37left*.png', '/Users/pplsuser/Desktop/All_frames/38left*.png', '/Users/pplsuser/Desktop/All_frames/39left*.png', '/Users/pplsuser/Desktop/All_frames/40left*.png', '/Users/pplsuser/Desktop/All_frames/41left*.png', '/Users/pplsuser/Desktop/All_frames/42left*.png', '/Users/pplsuser/Desktop/All_frames/43left*.png', '/Users/pplsuser/Desktop/All_frames/44left*.png', '/Users/pplsuser/Desktop/All_frames/45left*.png', '/Users/pplsuser/Desktop/All_frames/46left*.png', '/Users/pplsuser/Desktop/All_frames/47left*.png', '/Users/pplsuser/Desktop/All_frames/48left*.png', '/Users/pplsuser/Desktop/All_frames/49left*.png', '/Users/pplsuser/Desktop/All_frames/50left*.png', '/Users/pplsuser/Desktop/All_frames/51left*.png', '/Users/pplsuser/Desktop/All_frames/52left*.png', '/Users/pplsuser/Desktop/All_frames/53left*.png', '/Users/pplsuser/Desktop/All_frames/54left*.png', '/Users/pplsuser/Desktop/All_frames/55left*.png', '/Users/pplsuser/Desktop/All_frames/56left*.png', '/Users/pplsuser/Desktop/All_frames/57left*.png', '/Users/pplsuser/Desktop/All_frames/58left*.png', '/Users/pplsuser/Desktop/All_frames/59left*.png', '/Users/pplsuser/Desktop/All_frames/60left*.png', '/Users/pplsuser/Desktop/All_frames/61left*.png', '/Users/pplsuser/Desktop/All_frames/62left*.png', '/Users/pplsuser/Desktop/All_frames/63left*.png']
list_transitive_combinations_zip_left=zip(list_transitive_combinations_all64,indexes_trans_left)
list_transitive_combinations_zip_right=zip(list_transitive_combinations_all64,indexes_trans_right)
zip_trans=zip(list_transitive_combinations_zip_left,list_transitive_combinations_zip_right)
zip_int=zip(list_intransitive_combinations_zip_left,list_intransitive_combinations_zip_right)
list_test=zip_trans+zip_int
list_testing=zip(list_test,hol_tags_spaces_with_index)
zip_trans_tag=list_testing[:64]
zip_int_tag=list_testing[64:]
list_training_trans=random.sample(zip_trans_tag,32)
list_training_int=random.sample(zip_int_tag,12)
list_training=list_training_trans+list_training_int
fixed_training_list=list_training*3
fixed_testing_list=list_testing*2

number_trial=-1

for task_type in list_task_type[:]:
    number_trial +=1
    starting_pos=random.choice(['left', 'right'])
    starting_pos_alt=random.choice(['left', 'right'])
    scene_to_delete=random.choice(fixed_training_list)
    hol_tag=scene_to_delete[1][0]
    number_list=scene_to_delete[1][1]
    if starting_pos=='left':
        scene=scene_to_delete[0][0]
    elif starting_pos=='right':
        scene=scene_to_delete[0][1]
    if starting_pos_alt=='left':
        file_name1=random.choice(list_training)[0][0]
    elif starting_pos_alt=='right':
        file_name1=random.choice(list_training)[0][1]
    file_name=scene[1]
    scene_args=scene[0]
    #tag=scene_to_delete[2]
    while file_name1[1] == scene_to_delete[0][0][1] or file_name1[1] == scene_to_delete[0][1][1]:
        if starting_pos_alt=='left':
            file_name1=random.choice(list_training)[0][0]
        elif starting_pos_alt=='right':
            file_name1=random.choice(list_training)[0][1]    
    if scene_args in list_intransitive_combinations_all16:
        intransitive(myWin, scene_args[0], scene_args[1], scene_args[2], scene_args[3], scene_args[4],'first_part',ID,chain,task_type,starting_pos, number_trial,number_list,hol_tag)#add tag as an argument
    elif scene_args in list_transitive_combinations_all64:
        transitive(myWin, scene_args[0], scene_args[1], scene_args[2], scene_args[3], scene_args[4], scene_args[5], scene_args[6], scene_args[7],'first_part',ID,chain,task_type,starting_pos,number_trial, number_list,hol_tag)#add tag as an argument
    if task_type=='clicking':
        pos_alt=[[-0.5,0],[0.5,0]]
        index_alt=random.choice([0,1])
        pos_alt1=pos_alt[index_alt]
        if index_alt==0:
            pos_alt2=pos_alt[1]
        else:
            pos_alt2=pos_alt[0]
        box_alt1= visual.Rect(myWin, units='norm', width=0.9, height=0.7, pos=pos_alt1, lineColor='DimGray')
        box_alt2= visual.Rect(myWin, units='norm', width=0.9, height=0.7, pos=pos_alt2, lineColor='DimGray') 
        left_arrow=visual.ImageStim(myWin, image='/Users/pplsuser/Desktop/All_frames/f_key.png', units='norm', size=[0.15,0.15],pos=[-0.5,-0.55],flipHoriz=False,flipVert=False,autoLog=True)
        right_arrow=visual.ImageStim(myWin, image='/Users/pplsuser/Desktop/All_frames/j_key.png', units='norm', size=[0.15,0.15],pos=[0.5,-0.55],flipHoriz=False,flipVert=False,autoLog=True)
        tag_alt=visual.TextStim(myWin, units='norm', color='black',pos=[0,0.5], text='Which of the these scenes \n have you just seen?')
        box_alt1.setAutoDraw(True)
        box_alt2.setAutoDraw(True)
        left_arrow.setAutoDraw(True)
        right_arrow.setAutoDraw(True)
        timer=core.CountdownTimer(180)
        image_alt1_list=[]
        image_alt2_list=[]
        for image_alt1_name in glob.glob(file_name): image_alt1_list.append(image_alt1_name)
        for image_alt2_name in glob.glob(file_name1[1]): image_alt2_list.append(image_alt2_name)
        if 'perfective' in scene_args:
            more_frames= image_alt1_list[-1:]
            for i in range(30):
                for frame in more_frames: image_alt1_list.append(frame)
        elif 'perfective' in file_name1[0]:
            more_frames= image_alt2_list[-1:]
            for i in range(30):
                for frame in more_frames: image_alt2_list.append(frame)
        if len(image_alt1_list)>len(image_alt2_list):
            if 'perfective' in file_name1[0]:
                repeat_frame=image_alt2_list[-1:]
            else:
                repeat_frame=image_alt2_list[:len(image_alt1_list)-len(image_alt2_list)]
            for num_add in range(len(image_alt1_list)-len(image_alt2_list)):
                for frame in repeat_frame: image_alt2_list.append(frame)
        elif len(image_alt2_list)>len(image_alt1_list):
            if 'perfective' in scene_args:
                repeat_frame=image_alt1_list[-1:]
            else:
                repeat_frame=image_alt1_list[:len(image_alt1_list)-len(image_alt2_list)]            
            for num_add in range(len(image_alt2_list)-len(image_alt1_list)):
                for frame in repeat_frame: image_alt1_list.append(frame)
        image_alt_list=zip(image_alt1_list, image_alt2_list)
        while timer.getTime() >0:
            for image_alt in image_alt_list:
                    image_alt1= visual.ImageStim(myWin, image_alt[0], units='norm', size=[0.9, 0.7], pos=pos_alt1,flipHoriz=False,flipVert=False,autoLog=True)
                    image_alt2= visual.ImageStim(myWin, image_alt[1], units='norm', size=[0.9,0.7], pos=pos_alt2, flipHoriz=False,flipVert=False,autoLog=True)
                    tag_alt.draw()
                    image_alt1.draw()
                    image_alt2.draw()
                    myWin.flip()
                    core.wait(0.03)
                    if event.getKeys(['escape']):
                        myWin.close()
                        core.quit()
                    if event.getKeys(['f']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1[0]==-0.5:
                            append_to_file_xls('Correct', info["Participant's ID"],chain,number_trial)
                            append_to_file('Correct', info["Participant's ID"],chain)                    
                         else:
                            append_to_file_xls('Wrong', info["Participant's ID"],chain,number_trial)
                            append_to_file('Wrong', info["Participant's ID"],chain)
                         break
                    elif event.getKeys(['j']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1[0]==0.5: 
                            append_to_file('Correct', info["Participant's ID"],chain)                    
                            append_to_file_xls('Correct', info["Participant's ID"],chain,number_trial)
                         else:
                            append_to_file('Wrong', info["Participant's ID"],chain)
                            append_to_file_xls('Wrong', info["Participant's ID"],chain,number_trial)
                         break
        box_alt1.setAutoDraw(False)
        box_alt2.setAutoDraw(False)
        left_arrow.setAutoDraw(False)
        right_arrow.setAutoDraw(False)
    fixed_training_list.remove(scene_to_delete)


#SECOND PART
message10= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will now move onto the testing and communicating phase. This time you will be just shown the scenes without their descriptions. Type them when asked and hit return. ')
message10.draw()
next_page.draw()
next_tag.setPos([0.5,-0.6])
next_tag.setText('Proceed')
next_tag.draw()
myWin.flip()
event.waitKeys()

message11= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will now be typing to communicate the world and language you have just learned to an agent that has undergone the same training. The agent can ask you for more or new data if they cannot guess the scene you are describing.')
message11.draw()
next_page.draw()
next_tag.setPos([0.5,-0.6])
next_tag.setText('Proceed')
next_tag.draw()
myWin.flip()
event.waitKeys()

append_to_file('TESTING',ID,chain)

for test_trial in range(len(fixed_testing_list)):
    number_trial=test_trial+132
    starting_pos=random.choice(['left', 'right'])
    if starting_pos=='left':
        scene_to_delete=random.choice(fixed_testing_list)
        scene=scene_to_delete[0][0]
    elif starting_pos=='right':
        scene_to_delete=random.choice(fixed_testing_list)
        scene=scene_to_delete[0][1]
    hol_tag=scene_to_delete[1][0]
    number_list=scene_to_delete[1][1]    
    file_name=scene[1]
    scene_args=scene[0]
    #file_name1=random.choice(list_testing)
    #while file_name1[0]==file_name:
    #    file_name1=random.choice(list_testing)
    if scene_args in list_intransitive_combinations_all16:
        intransitive(myWin, scene_args[0], scene_args[1], scene_args[2], scene_args[3], scene_args[4],'second_part',info["Participant's ID"],chain,'retyping',starting_pos, number_trial,number_list, hol_tag)
    elif scene_args in list_transitive_combinations_all64:
        transitive(myWin, scene_args[0], scene_args[1], scene_args[2], scene_args[3], scene_args[4], scene_args[5], scene_args[6], scene_args[7],'second_part',info["Participant's ID"],chain,'retyping',starting_pos, number_trial, number_list,hol_tag)
    fixed_testing_list.remove(scene_to_delete)

message11= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='That is all. You have now finished the experiment. Thank you very much.')
message11.draw()
myWin.flip()
event.waitKeys()