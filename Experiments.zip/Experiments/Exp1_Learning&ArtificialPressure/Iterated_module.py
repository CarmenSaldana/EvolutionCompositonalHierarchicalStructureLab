#! /usr/bin/env python
from psychopy import core, visual,event
import time 
import numpy as np
import xlwt
from xlutils.copy import copy
from xlrd import open_workbook

list_leven=[]
#a routine to save responses to file anytime we want to
def saveThisResponse(captured_string,leven, target_string,list_leven,ID,chain):
    outfile = "./%d_%sResponses.txt"%(chain,ID)
    f = open(outfile, 'a') #open our results file in append mode so we don't overwrite anything
    f.write(captured_string) #write the string they typed    
    f.write('; typed at %s' %time.asctime()) #write a timestamp (very course)
    f.write(' Target: %s' %target_string)
    f.write(' Levenshtein distance:%d'%leven)
    f.write(' Accumulator: [')
    for item in list_leven:
        f.write('%s, '%item)
    f.write(']')
    f.write('\n') # write a line ending
    f.close() #close and "save" the output file

def saveResponse_xls(captured_string,leven, target_string, list_leven, ID,chain,number_trial):
    if number_trial == 0:
        wbk=xlwt.Workbook()
        responses_sheet=wbk.add_sheet('Exp_responses_%d_%s'%(chain,ID))
        responses_sheet.write(number_trial,0, target_string)
        responses_sheet.write(number_trial,1, captured_string)
        responses_sheet.write(number_trial,2, '%d'%leven)
        responses_sheet.write(number_trial,3,time.asctime())
        wbk.save('/Users/pplsuser/Desktop/Exp_%d_%s.xls'%(chain,ID))
    else:
        rb=open_workbook('/Users/pplsuser/Desktop/Exp_%d_%s.xls'%(chain,ID))
        #r_sheet=rb.sheet_by_index(0)
        wb=copy(rb)
        w_sheet=wb.get_sheet(0)
        w_sheet.write(number_trial,0, target_string)
        w_sheet.write(number_trial,1, captured_string)
        w_sheet.write(number_trial,2, '%d'%leven)
        w_sheet.write(number_trial,3,time.asctime())
        wb.save('/Users/pplsuser/Desktop/Exp_%d_%s.xls'%(chain,ID))
        
def iterated_output(captured_string, ID,chain, number_list,number_trial):
    if number_trial == 0:
        if chain==0:
            wbk=xlwt.Workbook()        
            responses_sheet1=wbk.add_sheet('Iteration_0_%s'%ID)
            wbk.add_sheet('Iteration_1_%s'%ID)
            wbk.add_sheet('Iteration_2_%s'%ID)
            wbk.add_sheet('Iteration_3_%s'%ID)                   
            responses_sheet1.write(number_list,0, captured_string) 
        else:
            wb=open_workbook('/Users/pplsuser/Desktop/Iterated_lists_sentences_%s.xls'%ID)
            wbk=copy(wb)
            sheet=wbk.get_sheet(chain)
            sheet.write(number_list,0, captured_string)       
        wbk.save('Iterated_lists_sentences_%s.xls'%ID)
    else:        
        rb=open_workbook('/Users/pplsuser/Desktop/Iterated_lists_sentences_%s.xls'%ID)
        #r_sheet=rb.sheet_by_index(0)
        wb=copy(rb)                  
        w_sheet=wb.get_sheet(chain)               
        w_sheet.write(number_list,0, captured_string)
        wb.save('Iterated_lists_sentences_%s.xls'%ID)

#get cells form file: x=open_workbook('name.xls')
#x.sheets()[num_sheet].cell_value(row,col)

def append_to_file(text,ID,chain):
    outfile = "./%d_%sResponses.txt"%(chain,ID)
    f = open(outfile, 'a') #open our results file in append mode so we don't overwrite anything
    f.write(text)
    f.write('\n') # write a line ending
    f.close() #close and "save" the output file
    
def append_to_file_xls(text,ID,chain,number_trial):
    rb=open_workbook('/Users/pplsuser/Desktop/Exp_%d_%s.xls'%(chain,ID))
    #r_sheet=rb.sheet_by_index(0)
    wb=copy(rb)
    w_sheet=wb.get_sheet(0)
    w_sheet.write(number_trial, 1, text)
    w_sheet.write(number_trial, 3, '%s' %time.asctime())
    wb.save('/Users/pplsuser/Desktop/Exp_%d_%s.xls'%(chain,ID))
    

#calculates the levenshtein distance
def levenshtein(str1, str2):
  d=dict()
  for i in range(len(str1)+1):
     d[i]=dict()
     d[i][0]=i
  for i in range(len(str2)+1):
     d[0][i] = i
  for i in range(1, len(str1)+1):
     for j in range(1, len(str2)+1):
        d[i][j] = min(d[i][j-1]+1, d[i-1][j]+1, d[i-1][j-1]+(not str1[i-1] == str2[j-1]))
  return d[len(str1)][len(str2)]
  
def allow_typing(myWin, ID,chain, target_string,number_trial,number_list):
    sans = ['Gill Sans MT', 'Arial','Helvetica','Verdana'] #use the first font found on this list
    CapturedResponseString = visual.TextStim(myWin, units='norm',height = 0.1,
                pos=(0, 0), text='',
                font=sans, 
                alignHoriz = 'center',alignVert='center',
                color='black')
    # now we will keep tracking what's happening on the keyboar until the participant hits the return key    
    captured_string = '' #empty for now.. this is a string of zero length that 
    # we will append our key presses to in sequence
    subject_response_finished = 0 # only changes when they hit return

    #check for Esc key / return key presses each frame
    while subject_response_finished == 0:
        for key in event.getKeys():
            #quit at any point
            if key in ['escape']: 
                myWin.close()
                core.quit()
            
            #if the participant hits return, save the string so far out 
            #and reset the string to zero length for the next trial
            elif key in ['return']:                
                leven=levenshtein(captured_string,target_string)
                list_leven.append(leven)
                print 'participant typed %s' %captured_string #show in debug window
                print 'Levenshtein: %d'%leven
                print list_leven
                if number_trial !=0: 
                    iterated_file=open_workbook('Iterated_lists_sentences_%s.xls'%ID)
                    r_sheet=iterated_file.sheet_by_index(chain)
                    typed_tags=[]
                    for i in range(r_sheet.nrows):
                        typed_tags.append(iterated_file.sheets()[chain].cell_value(i,0))                    
                    if captured_string in typed_tags[number_list+1:] or captured_string in typed_tags[:number_list]:
                        append_to_file('REUSE_%s'%captured_string, ID, chain)
                        rb=open_workbook('/Users/pplsuser/Desktop/Exp_%d_%s.xls'%(chain,ID))
                        #r_sheet=rb.sheet_by_index(0)
                        wb=copy(rb)
                        w_sheet=wb.get_sheet(0)
                        w_sheet.write(number_trial,4,'REUSE_%s'%captured_string)
                        wb.save('/Users/pplsuser/Desktop/Exp_%d_%s.xls'%(chain,ID))
                        captured_string = 'You have used this string for another scene, please type another one.'
                        CapturedResponseString.setColor('black')
                        CapturedResponseString.setText(captured_string)
                        CapturedResponseString.draw()
                        myWin.flip()
                        captured_string=''
                    else:
                        saveThisResponse(captured_string, leven, target_string,list_leven, ID,chain) #write to file
                        saveResponse_xls(captured_string,leven, target_string, list_leven, ID,chain,number_trial)
                        iterated_output(captured_string,ID,chain,number_list,number_trial)
                        captured_string = '' #reset to zero length 
                        subject_response_finished = 1 #allows the next trial to start
                else:
                    saveThisResponse(captured_string, leven, target_string,list_leven, ID,chain) #write to file
                    saveResponse_xls(captured_string,leven, target_string, list_leven, ID,chain,number_trial)
                    iterated_output(captured_string,ID, chain, number_list,number_trial)
                    captured_string = '' #reset to zero length 
                    subject_response_finished = 1 #allows the next trial to start
                
            #allow the participant to do deletions too , using the 
            # delete key, and show the change they made
            elif key in ['delete','backspace']:
                captured_string = captured_string[:-1] #delete last character
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
            #handle spaces
            elif key in ['space']:
                captured_string = captured_string+' '                
                #show it
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
            elif key in ['period']:
                captured_string = captured_string+'.'
                #show it
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
            elif key in ['comma']:
                captured_string = captured_string+','
                #show it
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
            elif key in ['lshift','rshift']:
                pass #do nothing when some keys are pressed
            #etc ...
            #if any other key is pressed, add it to the string and 
            # show the participant what they typed
            else:                 
                captured_string = captured_string+key
                #show it
                CapturedResponseString.setColor('DimGray')
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()


def bounce(myWin, list_targets,color, shape, number, aspect,text_tag, starting_pos,ID):  

    timer=core.CountdownTimer(5)    
    
    if starting_pos=='left':        
        start_pos=[[-0.65,0.65,0.1],[-0.4,0.4,0.1]]
        polarity=1
    else:
        start_pos=[[0.65,-0.65,-0.1],[0.4,-0.4,-0.1]]
        polarity=-1
        
    target=list_targets[0]
    target1=list_targets[1]
    target2=list_targets[2]
    target3=list_targets[3]
    target4=list_targets[4]
    target5=list_targets[5]
    target6=list_targets[6]
    target7=list_targets[7]
    target8=list_targets[8]
    if aspect=='perfective':
        if number=='singular':
            target.setAutoDraw(True)
            
            for i in np.arange(start_pos[0][0],start_pos[0][1],start_pos[0][2]):
                for z in [0,0.05]:                    
                    target.setPos([i,z])                            
                    myWin.flip()
                    core.wait(0.05)
            core.wait(4.5)                
        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)
            for i in np.arange(start_pos[1][0],start_pos[1][1],start_pos[1][2]):
                for z in [0,0.05]:
                    
                    target1.setPos([(-0.06*polarity)+i,0.15+z])
                    target4.setPos([(0.3*polarity)+i, -0.2+z])
                    target6.setPos([(-0.14*polarity)+i, 0+z])                    
                    target8.setPos([(-0.1*polarity)+i,-0.15+z])
                    myWin.flip()
                    core.wait(0.05)
                for y in [-0.05,0.045]:
                     
                     target.setPos([i, y])
                     target2.setPos([(0.06*polarity)+i, -0.18+y])
                     target3.setPos([(0.1*polarity)+i,0.15+y])
                     target5.setPos([(0.2*polarity)+i, -0.06+y])
                     target7.setPos([(0.24*polarity)+i, 0.24+y])                     
                     myWin.flip()
                     core.wait(0.05)
            core.wait(4.5)
    else:
        if number=='singular':
            target.setAutoDraw(True)
            while timer.getTime()>0:
                for t in range(1,3):
                    for i in np.arange(start_pos[0][0], start_pos[0][1],start_pos[0][2]):
                        for z in [0,0.05]:                            
                            target.setPos([i, z])
                            myWin.flip()
                            core.wait(0.05)
                    for i in np.arange(-start_pos[0][0]-(0.1*polarity),-start_pos[0][1],-start_pos[0][2]):
                        for z in [0,0.05]:                            
                            target.setPos([i, z])
                            myWin.flip()
                            core.wait(0.05)
        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)
            while timer.getTime()>0:
                for t in range(1,3):
                    for i in np.arange(start_pos[1][0], start_pos[1][1],start_pos[1][2]):
                        for z in [0,0.05]:                            
                            target1.setPos([(-0.06*polarity)+i,0.15+z])
                            target4.setPos([(0.3*polarity)+i, -0.2+z])
                            target6.setPos([(-0.14*polarity)+i, 0+z])
                            target8.setPos([(-0.1*polarity)+i,-0.15+z])                                                    
                            myWin.flip()
                            core.wait(0.05)
                        for y in [-0.05,0.045]:                             
                             target.setPos([i, y])
                             target2.setPos([(0.06*polarity)+i, -0.18+y])
                             target3.setPos([(0.1*polarity)+i,0.15+y])
                             target5.setPos([(0.2*polarity)+i, -0.06+y])
                             target7.setPos([(0.24*polarity)+i, 0.24+y])                         
                             myWin.flip()
                             core.wait(0.05)
                    for i in np.arange(-start_pos[1][0]-(0.1*polarity),-start_pos[1][1],-start_pos[1][2]):
                        for z in [0,0.05]:                            
                            target1.setPos([(-0.06*polarity)+i,0.15+z])
                            target4.setPos([(0.3*polarity)+i, -0.2+z])
                            target6.setPos([(-0.14*polarity)+i, 0+z])                        
                            target8.setPos([(-0.1*polarity)+i,-0.15+z])
                            myWin.flip()
                            core.wait(0.05)
                        for y in [-0.05,0.045]:                             
                             target.setPos([i, y])
                             target2.setPos([(0.06*polarity)+i, -0.18+y])
                             target3.setPos([(0.1*polarity)+i,0.15+y])
                             target5.setPos([(0.2*polarity)+i, -0.06+y])
                             target7.setPos([(0.24*polarity)+i, 0.24+y])                         
                             myWin.flip()
                             core.wait(0.05)
    for item_target in list_targets[:]:
        item_target.setAutoDraw(False)



def slide(myWin, list_targets,color, shape, number, aspect,text_tag, starting_pos,ID):
    timer=core.CountdownTimer(5)
    
    if starting_pos=='left':        
        start_pos=[[-0.65,0.65,0.1],[-0.4,0.4,0.1]]
        polarity=1
    else:
        start_pos=[[0.65,-0.65,-0.1],[0.4,-0.4,-0.1]]
        polarity=-1
        
    target=list_targets[0]
    target1=list_targets[1]
    target2=list_targets[2]
    target3=list_targets[3]
    target4=list_targets[4]
    target5=list_targets[5]
    target6=list_targets[6]
    target7=list_targets[7]
    target8=list_targets[8]
    if aspect=='perfective':
        if number=='singular':            
            target.setAutoDraw(True)            
            for i in np.arange(start_pos[0][0],start_pos[0][1],start_pos[0][2]):
                    target.setPos([i,0])                            
                    myWin.flip()
                    core.wait(0.05)
            core.wait(4.5)
        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)
            for i in np.arange(start_pos[1][0],start_pos[1][1],start_pos[1][2]):                    
                    target1.setPos([(-0.06*polarity)+i,0.15])
                    target4.setPos([(0.3*polarity)+i, -0.2])
                    target6.setPos([(-0.14*polarity)+i, 0])
                    target7.setPos([(0.24*polarity)+i, 0.24])                            
                    target.setPos([i, 0])
                    target2.setPos([(0.06*polarity)+i, -0.18])
                    target3.setPos([(0.1*polarity)+i,0.15])
                    target5.setPos([(0.2*polarity)+i, -0.06])
                    target8.setPos([(-0.1*polarity)+i,-0.15])
#                    for target_item in list_targets:
#                        target_item.setPos([(target_item.pos[0]*polarity)+i, target_item.pos[1]])
                    myWin.flip()
                    core.wait(0.05)
            core.wait(4.5)
    else:
        if number=='singular':
            target.setAutoDraw(True)
            while timer.getTime()>0:
                for t in range(1,3):
                    for i in np.arange(start_pos[0][0],start_pos[0][1],start_pos[0][2]):                            
                            target.setPos([i, 0])
                            myWin.flip()
                            core.wait(0.05)
                    for i in np.arange(-start_pos[0][0]-(0.1*polarity), -start_pos[0][1],-start_pos[0][2]):                            
                            target.setPos([i, 0])
                            myWin.flip()
                            core.wait(0.05)

        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)
            while timer.getTime()>0:
                for t in range(1,3):
                    for i in np.arange(start_pos[1][0],start_pos[1][1],start_pos[1][2]):
                            target1.setPos([(-0.06*polarity)+i,0.15])
                            target4.setPos([(0.3*polarity)+i, -0.2])
                            target6.setPos([(-0.14*polarity)+i, 0])
                            target7.setPos([(0.24*polarity)+i, 0.24])                            
                            target.setPos([i, 0])
                            target2.setPos([(0.06*polarity)+i, -0.18])
                            target3.setPos([(0.1*polarity)+i,0.15])
                            target5.setPos([(0.2*polarity)+i, -0.06])
                            target8.setPos([(-0.1*polarity)+i,-0.15])
#                            for target_item in list_targets:
#                                target_item.setPos([(target_item.pos[0]*polarity)+i, target_item.pos[1]])
                            myWin.flip()
                            core.wait(0.05)
                    for i in np.arange(-start_pos[1][0]-(0.1*polarity),-start_pos[1][1],-start_pos[1][2]):
                            target1.setPos([(-0.06*polarity)+i,0.15])
                            target4.setPos([(0.3*polarity)+i, -0.2])
                            target6.setPos([(-0.14*polarity)+i, 0])
                            target7.setPos([(0.24*polarity)+i, 0.24])                            
                            target.setPos([i, 0])
                            target2.setPos([(0.06*polarity)+i, -0.18])
                            target3.setPos([(0.1*polarity)+i,0.15])
                            target5.setPos([(0.2*polarity)+i, -0.06])
                            target8.setPos([(-0.1*polarity)+i,-0.15])
#                            for target_item in target_list:
#                                target_item.setPos([(target_item.pos[0]*polarity)+i, target_item.pos[1]])
                            myWin.flip()
                            core.wait(0.05)

    for item_target in list_targets:
        item_target.setAutoDraw(False)


size_shapes=[0.08,0.12]
size_shapes_objects=[0.08, 0.12]

def intransitive(myWin, color, shape, number, movement, aspect,part,ID,chain,task,starting_pos,number_trial,number_list,hol_tag):
    if starting_pos=='left':        
        start_pos=[[-0.65,0.65,0.1],[-0.4,0.4,0.1]]
        polarity=1
    else:
        start_pos=[[0.65,-0.65,-0.1],[0.4,-0.4,-0.1]]
        polarity=-1
    target=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0*polarity)+start_pos[0][0],0])
    target1=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.06*polarity)+start_pos[0][0],0.15])
    target2=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.06*polarity)+start_pos[0][0],-0.18])
    target3=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.1*polarity)+start_pos[0][0],0.15])
    target4=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.3*polarity)+start_pos[0][0],-0.2])
    target5=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.2*polarity)+start_pos[0][0], -0.06])
    target6=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.24*polarity)+start_pos[0][0],0])
    target7=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.24*polarity)+start_pos[0][0], 0.24])
    target8=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.2*polarity)+start_pos[0][0],-0.15])    
    list_targets=[target,target1,target2,target3,target4,target5,target6, target7,target8]
    text_tag_int=hol_tag
    tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0.55], text=text_tag_int)
    if part=='first_part':
        tag.setAutoDraw(True)
#        tag.setPos([0,0])
        myWin.flip()
        core.wait(2)
#        tag.setPos([0,0.55])
        if movement=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_int,starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect,text_tag_int, starting_pos,ID)

        tag.setAutoDraw(False)
    else:
        if movement=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_int,starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect,text_tag_int,starting_pos,ID)
    if task=='retyping':
        tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0], text='Retype now, please.')        
        tag.draw()
        myWin.flip()
        allow_typing(myWin, ID,chain, text_tag_int,number_trial,number_list)

    
def transitive(myWin, color, color_obj, shape, shape_obj,number, number_obj, movement_trans, aspect, part, ID,chain,task,starting_pos, number_trial,number_list,hol_tag):
    if starting_pos=='right':
        starting_pos_obj= 'left'
    else:
        starting_pos_obj='right'
        
    if number_obj =='singular':
        num_obj=1
    else:
        num_obj=9
        

    if starting_pos=='left':        
        start_pos=[[-0.65,0.65,0.1],[-0.4,0.4,0.1]]
        polarity=1
    else:
        start_pos=[[0.65,-0.65,-0.1],[0.4,-0.4,-0.1]]
        polarity=-1
        
    target=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0*polarity)+start_pos[0][0],0])
    target1=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.06*polarity)+start_pos[0][0],0.15])
    target2=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.06*polarity)+start_pos[0][0],-0.18])
    target3=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.1*polarity)+start_pos[0][0],0.15])
    target4=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.3*polarity)+start_pos[0][0],-0.2])
    target5=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.2*polarity)+start_pos[0][0], -0.06])
    target6=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.24*polarity)+start_pos[0][0],0])
    target7=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.24*polarity)+start_pos[0][0], 0.24])
    target8=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.2*polarity)+start_pos[0][0],-0.15])    
    list_targets=[target,target1,target2,target3,target4,target5,target6, target7,target8]
    
    target_object1=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.8-0.1,0.1])
    target_object=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.76-0.1, -0.01])
    target_object2=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.88-0.1, 0.2])
    target_object3=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.73-0.1, -0.15])
    target_object4=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.85-0.1, -0.24])
    target_object5=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.7-0.1, 0.13])
    target_object6=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.76-0.1, 0.25])
    target_object7=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.88-0.1, -0.07])
    target_object8=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.9-0.1, 0.07])
    list_targets_obj=[target_object, target_object1, target_object2, target_object3, target_object4, target_object5, target_object6, target_object7, target_object8]
    
    text_tag_trans=hol_tag
    tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0.55], text=text_tag_trans)

            
    if part=='first_part':
        tag.setAutoDraw(True)
#        tag.setPos([0,0])
        myWin.flip()
        core.wait(2)
#        tag.setPos([0,0.55])
        if starting_pos_obj == 'right':
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)
        else:
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)    
                item.setPos([-item.pos[0], -item.pos[1]])
        if movement_trans=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_trans, starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect,text_tag_trans, starting_pos,ID)
        tag.setAutoDraw(False)
    else:
        if starting_pos_obj == 'right':
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)
        else:
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)    
                item.setPos([-item.pos[0], -item.pos[1]])
        if movement_trans=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_trans, starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect, text_tag_trans, starting_pos,ID)
    for item in list_targets_obj[:num_obj]:
        item.setAutoDraw(False)
    if task=='retyping':
        tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0], text='Retype now, please')        
        tag.draw()
        myWin.flip()
        allow_typing(myWin, ID, chain, text_tag_trans,number_trial,number_list)