#! /usr/bin/env python

#if __name__=='__main__':

#SERVER VERSION

from psychopy import core, visual, gui, event
from xlrd import open_workbook
from comu_module import *
from socket import *
import glob
import random

#designate a server
#input other machines ip address
#find your own ip address
SERVER=False
OTHER_IP_ADDR= gethostbyname(gethostname())#'129.215.112.209'

MY_IP_ADDR= '127.0.0.1' 



#reclute participant's ID
info = {"Chain":'',"Participant's ID":'', "Role":''}
infoDlg = gui.DlgFromDict(dictionary=info, title='TestExperiment', fixed=['ExpVersion'])
if infoDlg.OK:
    print info
else: print 'User Cancelled'

ID=info["Participant's ID"]
chain=int(info["Chain"])
myRole=info["Role"]
ID_minus_one= int(float(ID))-1
ID_iterated_string=str(ID_minus_one)

list_task_type=list_task_type()
#lists_str=receive_message(True)
#lists=eval(lists_str)
#lists=t_lists(chain, ID_iterated_string,list_input)
lists=read_test_list(chain,ID)
list_training=lists[0]
list_testing=lists[1]+lists[2]
fixed_list_training=lists[0]*3
#fixed_list_testing=lists[1]*2
test_list=lists[2]

path='/Users/pplsuser/Desktop/All_frames/'

myWin = visual.Window((1066.67,666.67),color='white', allowGUI=True,
            monitor='testMonitor', units ='deg')#((1240,800),color='white', allowGUI=True,monitor='testMonitor', units ='deg', fullscr=True)

waiting_connection(myWin)

#if server, create a socket and bind it to own ip address
#if not server, create socket and connect it to servers ip address
if SERVER:
    s=socket(AF_INET,SOCK_STREAM)
    s.bind((MY_IP_ADDR,7213))
    s.listen(1)
    c, a=s.accept()
    SOCKET=c
else:
    s=socket(AF_INET,SOCK_STREAM)
    s.connect((OTHER_IP_ADDR,7213))
    SOCKET=s

#sends a message to other machine
def send_message(message):
    SOCKET.send(message)

#listens for message from other machine, whether blocked or unblocked
def receive_message(blocked):
    SOCKET.setblocking(blocked)
    try:
        return SOCKET.recv(1024)
    except:
        return ''

#myWin.setMouseVisible(False)

if SERVER:
    role='send'
else:
    role='recv'

#Instructions



intro_info(myWin,myRole,path)

#TRAINING
append_to_file('TRAINING', ID,chain,myRole)

number_trial=-1

for task_type in list_task_type[:0]:
    number_trial +=1
    starting_pos=random.choice(['left', 'right'])
    scenes=scenes_0scene_1foil_2tag_3index_4scenedelete_56otherfoils(list_training,fixed_list_training,starting_pos)
    scene=scenes[0]
    scene_args=scene[0]
    file_scene=scene[1]
    foil=scenes[1]
    scene_tag=scenes[2]
    scene_index=scenes[3]
    scene_to_delete=scenes[4]
    number_list=scene_to_delete[1][1]
    if len(scene_args)==5:
        intransitive(myWin, scene_args[0], scene_args[1], scene_args[2], scene_args[3], scene_args[4],'first_part',ID,chain,task_type,starting_pos, number_trial,number_list,scene_tag,myRole, SOCKET, role)#add tag as an argument
    elif len(scene_args)==8:
        transitive(myWin, scene_args[0], scene_args[1], scene_args[2], scene_args[3], scene_args[4], scene_args[5], scene_args[6], scene_args[7],'first_part',ID,chain,task_type,starting_pos,number_trial, number_list,scene_tag, myRole, SOCKET, role)#add tag as an argument
    
    if task_type=='clicking':
        #wait_load(myWin)
        tag='Which of the these scenes \n have you just seen'
        discrimination_task(myWin,scene,foil,chain,ID,number_trial,myRole,tag,'first_part',SOCKET,path) 
    fixed_list_training.remove(scene_to_delete)


#TESTING
append_to_file('TESTING',ID,chain,myRole)

test_instructions(myWin,myRole,path)

#number_test_trials=6
for test_trial in range(len(list_testing)):
    number_trial=test_trial+120
    #if test_trial%2 == 0:
    #    test_list=test_list_even
    #elif test_trial%2 ==1:
    #    test_list=test_list_odd
    starting_pos=random.choice(['left', 'right'])
    if role=='send':
        #if test_trial==0:
        #    draw_fixation(myWin)        
        scenes_test=scenes_0scene_1foil_2tag_3index_4scenedelete_56otherfoils(list_testing,test_list,starting_pos)
        send_message(str(scenes_test))
        scene_test=scenes_test[0]
        scene_args_test=scene_test[0]
        number_list= scenes_test[4][1][1]
        scene_tag=scenes_test[2]
        scene_to_delete_test=scenes_test[4] 
        if len(scene_args_test)==5:
            intransitive(myWin, scene_args_test[0], scene_args_test[1], scene_args_test[2], scene_args_test[3], scene_args_test[4],'second_part',ID,chain,'retyping',starting_pos, number_trial,number_list, scene_tag,myRole, SOCKET, role)
        elif len(scene_args_test)==8:
            transitive(myWin, scene_args_test[0], scene_args_test[1], scene_args_test[2], scene_args_test[3], scene_args_test[4], scene_args_test[5], scene_args_test[6], scene_args_test[7],'second_part',ID,chain,'retyping',starting_pos, number_trial, number_list,scene_tag,myRole, SOCKET, role)
        test_list.remove(scene_to_delete_test)
        print len(test_list)        
        wait_feedback(myWin)
        response=receive_message(True)        
        response=eval(response)
        feedback_message(myWin,response[0],response[1],response[2],response[3],response[4],path,response[5],role) 
    elif role=='recv':
        wait_text(myWin)
        scenes_t=receive_message(True)
        scenes_test=eval(scenes_t)
        scene_test=scenes_test[0]
        foil_test=scenes_test[1]
        foil_test1=scenes_test[5]
        foil_test2=scenes_test[6]
        #scene_to_delete_test=scenes_test[4]
        tag=receive_message(True)        
        discrimination_task_testing(myWin,scene_test,foil_test,foil_test1,foil_test2,chain,ID,number_trial,myRole,tag,'second_part',SOCKET,path,role)
        #test_list.remove(scene_to_delete_test)
        #print len(test_list)
        #if test_trial != len(range(number_test_trials))-1:
        #    draw_fixation(myWin)
    #if test_trial%2 == 0:
    #    test_list_even.remove(scene_to_delete_test)
    #elif test_trial%2 == 1:
    #    test_list_odd.remove(scene_to_delete_test)
    if role=='send':
        role='recv'
    elif role=='recv':
        role='send'

final_message(myWin)
SOCKET.close()