#! /usr/bin/env python
from psychopy import core, visual,event
import time, random
import numpy as np
import xlwt
from xlutils.copy import copy
from xlrd import open_workbook
from socket import *
import glob
from operator import mul
from PIL import Image
import pickle

#sends a message to other machine
def send_a_message(message,socket):
    socket.send(message)

#listens for message from other machine, whether blocked or unblocked
#only need unblocked if both machines need to send messages at the same time, or listen for more than 1 message
#HOWEVER, if unblocked and no message is present, an error will be returned, which is why Simon included this try/except command
#only returns something if a message is actually received
#Simon is worried that this is a dodgy way around this
def receive_a_message(blocked,socket):
    socket.setblocking(blocked)
    try:
        return socket.recv(1024)
    except:
        return ''

def waiting_connection(myWin):
    openscreen = visual.TextStim(myWin, text="Waiting for connection...", units='deg', color='black')
    openscreen.draw()
    myWin.flip()
      
def intro_info(myWin,myRole,path):
    message1 = visual.TextStim(myWin, color='black', units='norm',pos=[0,0],text='In this experiment you will learn an alien language that you will later use to communicate with your partner.')
    message2 = visual.TextStim(myWin, color='black',units='norm',pos=[0,0], text="The task is divided into two parts.")
    message3 = visual.TextStim(myWin, color='black', units='norm',pos=[0,0],text='In the first part, you will be trained on an alien language.')
    message4= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='In the second part, you will communicate with your partner using the alien language.')# in the alien language to test how well you can interact using the learned language.')
    message5= visual.TextStim(myWin, color='black', units='norm', pos=[0,0.0], text='In the training phase, you will be shown different scenes with their corresponding descriptions displayed in text on the screen.')
    message6= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Sometimes you will be asked to retype the description, please retype it and then press return to confirm.')
    message7= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Other times you will be asked to recognise the scene you were just shown by choosing between two scenes, please press the key indicated under the scene to select it.')
    message8= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='After the training phase there will be a communication phase. You will communicate with your partner using the alien language.')
    #message9=visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will be asked for the description of a scene, please type the description when asked and press return.Your partner will then pick the image they think you meant. You and your partner will then see the word you used,the scene it described and the scene your partner picked.' )
    #message9bis=visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will see the description from your partner in the middle of the screen, please press the key below the scene to select it. Also, every other time you will be asked to describe a scene so your partner can identify it, please type the description when asked and press return.' )
    #message10= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='This communication turn-taking process will be repeated throughout.')
    message11= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Hit return when you are ready to begin the training phase.')
    next_page=visual.ImageStim(myWin, image=path+'return_key.png', units='norm', size=[0.2,0.2],pos=[0.7,-0.6],flipHoriz=False,flipVert=False,autoLog=True)
    next_tag= visual.TextStim(myWin, color='black', units='norm', pos=[0.55,-0.6], text='Next')
    message1.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    message2.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    message3.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    message4.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    message5.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    message6.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    message7.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()

    message8.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()

    #if myRole=='server':
    #    message9.draw()
    #    next_page.draw()
    #    next_tag.draw()
    #    myWin.flip()
    #    event.waitKeys()
    #elif myRole=='client':
    #    message9bis.draw()
    #    next_page.draw()
    #    next_tag.draw()
    #    myWin.flip()
    #    event.waitKeys()
    #message10.draw()
    #next_page.draw()
    #next_tag.draw()
    #myWin.flip()
    #event.waitKeys()
    message11.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    
def test_instructions(myWin,myRole,path):
    message_sync=visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Please let the experimenter know you have completed the training before proceeding. Thank you.')
    message12= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will now move onto the communicating phase. You will take turns describing scenes for your partner, and interpreting your partner\'s descriptions.')# with your partner to communicate in the alien language you both have just been trained on.')
    message13= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='We will measure whether you and your partner can succesfully communicate. Remember that you are not allowed to use English!')
    message14s= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will first be asked to describe a scene so your partner can identify it. Type a description when asked and press return. Your partner will receive your description and then pick the image they think you meant.')
    message15s= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You and your partner will then see the scene you described, the description you used,  and the scene your partner picked. You will also be told whether communication was successful.')
    message16s= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Then it will be your partner\'s turn to provide a description. Your screen will display \'Waiting for partner\' until your partner sends the description. ')
    message17s= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will then see your partner\'s description, please press the key below the scene you think your partner was describing. You will then get feeback on how you and your partner got on there too.')
    message14r= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='First it will be your partner\'s turn to provide a description. Your screen will display \'Waiting for partner\' until your partner sends the description.')
    message15r= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will then see your partner\'s description, please press the key below the scene you think your partner was describing. You and your partner will then see the scene your partner saw, their description, the scene you picked, and whether communication was successful.')
    message16r= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Next, it will be your turn to describe a scene so your partner can identify it. Type a description when asked and press return. Your partner will receive your description and then pick the scene they think you meant.')
    message17r= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will then get the feeback from your partner\'s performance and your communicative success as before.')
    
    
    message18= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='You will repeat this turn-taking process until the end of the experiment.')
    message19= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='Hit return when you are ready to start.')
    next_page=visual.ImageStim(myWin, image=path+'return_key.png', units='norm', size=[0.2,0.2],pos=[0.7,-0.6],flipHoriz=False,flipVert=False,autoLog=True)
    next_page=visual.ImageStim(myWin, image=path+'return_key.png', units='norm', size=[0.2,0.2],pos=[0.7,-0.6],flipHoriz=False,flipVert=False,autoLog=True)
    next_tag= visual.TextStim(myWin, color='black', units='norm', pos=[0.5,-0.6], text='Proceed')
    
    message_sync.draw()       
    myWin.flip()
    event.waitKeys()
    message12.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    message13.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()    
    if myRole=='server':
        message14s.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys()
    elif myRole=='client':
        message14r.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys()
    if myRole=='server':
        message15s.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys()
    elif myRole=='client':
        message15r.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys() 
    if myRole=='server':
        message16s.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys()
    elif myRole=='client':
        message16r.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys()
    if myRole=='server':
        message17s.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys()
    elif myRole=='client':
        message17r.draw()
        next_page.draw()
        next_tag.draw()
        myWin.flip()
        event.waitKeys()        
    message18.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()
    message19.draw()
    next_page.draw()
    next_tag.draw()
    myWin.flip()
    event.waitKeys()

def feedback_message(myWin,feedback,image_all,pos_image,pos_text,string,path,press_foil,role):
    if role=='send':
        feed='Your partner'
        me='You'
    else:
        feed='You'
        me='Your partner'    
    message_feedback=visual.TextStim(myWin, color='black', units='norm', pos=[0,0.8], text=feedback) 
    pos_sig=np.add(pos_image,[0,0.3])   
    signal_m=visual.TextStim(myWin, color='DimGray', units='norm', pos=pos_sig, text='%s saw'%me)
    signal=visual.TextStim(myWin, color='black', units='norm', pos=[0,0.5], text=string)
    signal_foil=visual.TextStim(myWin, color='DimGray', units='norm', pos=np.add(pos_text,[0,0.3]),text='%s picked'%feed)
    box= visual.Rect(myWin, units='norm', width=0.8, height=0.7, pos=np.add(pos_image,[0,-0.1]), lineColor='DimGray')
    box_sel= visual.Rect(myWin, units='norm', width=0.8, height=0.7, pos=np.add(pos_text,[0,-0.1]), lineColor='DimGray')     
    timer=core.CountdownTimer(2)
    image_list=[]
    image_list_sel=[]
    for image_alt1_name in glob.glob(path+image_all[1]): image_list.append(image_alt1_name)
    if 'perfective' in image_all[0]:
        more_frames= image_list[-1:]
        for i in range(44):
            for frame in more_frames: image_list.append(frame)
            
    if 'Sorry' in feedback:
        for image_alt2_name in glob.glob(path+press_foil[1]): image_list_sel.append(image_alt2_name)
        if 'perfective' in press_foil[0]:
            more_frames= image_list_sel[-1:]
            for i in range(44):
                for frame in more_frames: image_list_sel.append(frame)
        images_list=zip(image_list,image_list_sel)
    else:
        images_list=zip(image_list,image_list)

    if 'Sorry' not in feedback:
        #vis='green'
        fondo='PaleGreen'
    else:
        #vis='red'
        fondo='tomato'
    #    while timer.getTime() >0:
    #        for image in image_list:
    #            pre_draw=timer.getTime()
    #            meaning= visual.ImageStim(myWin, image, units='norm', size=[0.8, 0.7], pos=[0,0],flipHoriz=False,flipVert=False,autoLog=True)
    #            message_feedback.setColor('green')
    #            message_feedback.draw()
    #            meaning.draw()                
    #            signal.setPos([0,0.5])
    #            signal.draw()
    #            box.setPos([0,0])
    #            box.draw()
    #            myWin.flip()
    #            core.wait(0.08-abs(pre_draw-timer.getTime()))
    #else:
    while timer.getTime() >0:
        for image in images_list:
            pre_draw=timer.getTime()
            meaning= visual.ImageStim(myWin, image[0], units='norm', size=[0.8, 0.7], pos=np.add(pos_image,[0,-0.1]),flipHoriz=False,flipVert=False,autoLog=True)
            signal_frames= visual.ImageStim(myWin, image[1], units='norm', size=[0.8, 0.7], pos=np.add(pos_text,[0,-0.1]),flipHoriz=False,flipVert=False,autoLog=True)
            background= visual.Rect(myWin, units='norm', width=4, height=6, pos=np.add(pos_image,[0,-0.1]), fillColor=fondo)#(1066.67,666.67)
            background.draw()
            message_feedback.setColor('DimGray')
            message_feedback.draw()
            signal_m.draw()
            signal_foil.draw()
            meaning.draw()
            signal.draw()
            signal_frames.draw()
            #box.setLineColor('green')
            box.draw()
            #box_sel.setLineColor('red')
            box_sel.draw()
            myWin.flip()
            core.wait(0.08-abs(pre_draw-timer.getTime()))        

def draw_fixation(myWin):
   fixation = visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='+') 
   fixation.draw()
   myWin.flip()
   core.wait(0.25)
    
def wait_text(myWin):
    waittext = visual.TextStim(myWin, text="Waiting for partner...", units='deg', color='black')
    waittext.draw()
    myWin.flip()

def wait_load(myWin):
    fixation1 = visual.TextStim(myWin, color='black', units='norm', pos=[-0.5,0], text='+') 
    fixation2 = visual.TextStim(myWin, color='black', units='norm', pos=[0.5,0], text='+') 
    #waittext = visual.TextStim(myWin, text="", units='deg', color='black')
    #waittext.draw()
    fixation1.draw()
    fixation2.draw()
    myWin.flip()
    
def wait_feedback(myWin):
    waittext = visual.TextStim(myWin, text="Waiting for feedback...", units='deg', color='black')
    waittext.draw()
    myWin.flip()
    

def final_message(myWin):
    message11= visual.TextStim(myWin, color='black', units='norm', pos=[0,0], text='That is all. You have now finished the experiment. Thank you very much.')
    message11.draw()
    myWin.flip()
    event.waitKeys()
    
def list_task_type():
    list_132=['retyping']*60+['clicking']*60
    list_tasks=random.sample(list_132,len(list_132))
    while list_tasks[0]=='clicking':
        list_tasks=random.sample(list_132,len(list_132))
    return list_tasks

def all_indices(value, qlist):
    indices = []
    idx = -1
    while True:
        try:
            idx = qlist.index(value, idx+1)
            indices.append(idx)
        except ValueError:
            break
    return indices

def thingy(dimensions,test_list_halved):
    naked_test_list_halved=[j[0][0][0] for j in test_list_halved]
    count=0
    for i in dimensions:
        indices=all_indices(i,dimensions)
        #print indices
        for x in indices:
            s=[g[x] for g in naked_test_list_halved]
            #print s
            for item in i:
                if item in s:
            #for f in all(item in s for item in i): 
                #if f==True:
                    count+=1
    return count
    

def t_lists(chain, generation,random_list):
    iterated_tags_file=open_workbook('Iterated_output_dyads_00%s_%s.xls'%(generation,random_list))
    sheety=iterated_tags_file.sheet_by_index(chain)
    hol_tags_spaces=[]
    for i in range(sheety.nrows):
        string_tag=iterated_tags_file.sheets()[chain].cell_value(i,0)
        hol_tags_spaces.append(string_tag.strip())
    if len(hol_tags_spaces)!= 80:
        for t in range(80-len(hol_tags_spaces)):
            hol_tags_spaces.append('')
    hol_tags_spaces_with_index=zip(hol_tags_spaces,range(80))
    #list(itertools.product(*a))
    dim_trans=[('DeepPink','DeepPink'),('DeepPink','DeepPink'),('raisedCos','None'),('raisedCos','None'), ('singular','plural'),('singular','plural'),('bounce','slide'),('perfective','continuous')]
    dim_int=[('DeepPink','DeepPink'),('raisedCos','None'), ('singular','plural'),('bounce','slide'),('perfective','continuous')]
    list_intransitive_combinations_all16=[('DeepPink', 'raisedCos', 'singular', 'bounce', 'perfective'), ('DeepPink', 'raisedCos', 'singular', 'bounce', 'continuous'), ('DeepPink', 'raisedCos', 'singular', 'slide', 'perfective'), ('DeepPink', 'raisedCos', 'singular', 'slide', 'continuous'), ('DeepPink', 'raisedCos', 'plural', 'bounce', 'perfective'), ('DeepPink', 'raisedCos', 'plural', 'bounce', 'continuous'), ('DeepPink', 'raisedCos', 'plural', 'slide', 'perfective'), ('DeepPink', 'raisedCos', 'plural', 'slide', 'continuous'), ('DeepPink', 'None', 'singular', 'bounce', 'perfective'), ('DeepPink', 'None', 'singular', 'bounce', 'continuous'), ('DeepPink', 'None', 'singular', 'slide', 'perfective'), ('DeepPink', 'None', 'singular', 'slide', 'continuous'), ('DeepPink', 'None', 'plural', 'bounce', 'perfective'), ('DeepPink', 'None', 'plural', 'bounce', 'continuous'), ('DeepPink', 'None', 'plural', 'slide', 'perfective'), ('DeepPink', 'None', 'plural', 'slide', 'continuous')]
    list_transitive_combinations_all64=[('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'raisedCos', 'plural', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'raisedCos', 'None', 'plural', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'raisedCos', 'plural', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'singular', 'plural', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'singular', 'slide', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'bounce', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'bounce', 'continuous'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'slide', 'perfective'), ('DeepPink', 'DeepPink', 'None', 'None', 'plural', 'plural', 'slide', 'continuous')]
    #indexes_int_left=['/Users/pplsuser/Desktop/All_frames/00left*.png', '/Users/pplsuser/Desktop/All_frames/01left*.png', '/Users/pplsuser/Desktop/All_frames/02left*.png', '/Users/pplsuser/Desktop/All_frames/03left*.png', '/Users/pplsuser/Desktop/All_frames/04left*.png', '/Users/pplsuser/Desktop/All_frames/05left*.png', '/Users/pplsuser/Desktop/All_frames/06left*.png', '/Users/pplsuser/Desktop/All_frames/07left*.png', '/Users/pplsuser/Desktop/All_frames/08left*.png', '/Users/pplsuser/Desktop/All_frames/09left*.png', '/Users/pplsuser/Desktop/All_frames/010left*.png', '/Users/pplsuser/Desktop/All_frames/011left*.png', '/Users/pplsuser/Desktop/All_frames/012left*.png', '/Users/pplsuser/Desktop/All_frames/013left*.png', '/Users/pplsuser/Desktop/All_frames/014left*.png', '/Users/pplsuser/Desktop/All_frames/015left*.png']
    indexes_int_left=['00left*.png', '01left*.png', '02left*.png', '03left*.png', '04left*.png', '05left*.png', '06left*.png', '07left*.png', '08left*.png', '09left*.png', '010left*.png', '011left*.png', '012left*.png', '013left*.png', '014left*.png', '015left*.png']
    #indexes_int_right=['/Users/pplsuser/Desktop/All_frames/00right*.png', '/Users/pplsuser/Desktop/All_frames/01right*.png', '/Users/pplsuser/Desktop/All_frames/02right*.png', '/Users/pplsuser/Desktop/All_frames/03right*.png', '/Users/pplsuser/Desktop/All_frames/04right*.png', '/Users/pplsuser/Desktop/All_frames/05right*.png', '/Users/pplsuser/Desktop/All_frames/06right*.png', '/Users/pplsuser/Desktop/All_frames/07right*.png', '/Users/pplsuser/Desktop/All_frames/08right*.png', '/Users/pplsuser/Desktop/All_frames/09right*.png', '/Users/pplsuser/Desktop/All_frames/010right*.png', '/Users/pplsuser/Desktop/All_frames/011right*.png', '/Users/pplsuser/Desktop/All_frames/012right*.png', '/Users/pplsuser/Desktop/All_frames/013right*.png', '/Users/pplsuser/Desktop/All_frames/014right*.png', '/Users/pplsuser/Desktop/All_frames/015right*.png']
    indexes_int_right=['00right*.png', '01right*.png', '02right*.png', '03right*.png', '04right*.png', '05right*.png', '06right*.png', '07right*.png', '08right*.png', '09right*.png', '010right*.png', '011right*.png', '012right*.png', '013right*.png', '014right*.png', '015right*.png']
    list_intransitive_combinations_zip_left=zip(list_intransitive_combinations_all16,indexes_int_left)
    list_intransitive_combinations_zip_right=zip(list_intransitive_combinations_all16,indexes_int_right)
    #indexes_trans_right=['/Users/pplsuser/Desktop/All_frames/0right*.png', '/Users/pplsuser/Desktop/All_frames/1right*.png', '/Users/pplsuser/Desktop/All_frames/2right*.png', '/Users/pplsuser/Desktop/All_frames/3right*.png', '/Users/pplsuser/Desktop/All_frames/4right*.png', '/Users/pplsuser/Desktop/All_frames/5right*.png', '/Users/pplsuser/Desktop/All_frames/6right*.png', '/Users/pplsuser/Desktop/All_frames/7right*.png', '/Users/pplsuser/Desktop/All_frames/8right*.png', '/Users/pplsuser/Desktop/All_frames/9right*.png', '/Users/pplsuser/Desktop/All_frames/10right*.png', '/Users/pplsuser/Desktop/All_frames/11right*.png', '/Users/pplsuser/Desktop/All_frames/12right*.png', '/Users/pplsuser/Desktop/All_frames/13right*.png', '/Users/pplsuser/Desktop/All_frames/14right*.png', '/Users/pplsuser/Desktop/All_frames/15right*.png', '/Users/pplsuser/Desktop/All_frames/16right*.png', '/Users/pplsuser/Desktop/All_frames/17right*.png', '/Users/pplsuser/Desktop/All_frames/18right*.png', '/Users/pplsuser/Desktop/All_frames/19right*.png', '/Users/pplsuser/Desktop/All_frames/20right*.png', '/Users/pplsuser/Desktop/All_frames/21right*.png', '/Users/pplsuser/Desktop/All_frames/22right*.png', '/Users/pplsuser/Desktop/All_frames/23right*.png', '/Users/pplsuser/Desktop/All_frames/24right*.png', '/Users/pplsuser/Desktop/All_frames/25right*.png', '/Users/pplsuser/Desktop/All_frames/26right*.png', '/Users/pplsuser/Desktop/All_frames/27right*.png', '/Users/pplsuser/Desktop/All_frames/28right*.png', '/Users/pplsuser/Desktop/All_frames/29right*.png', '/Users/pplsuser/Desktop/All_frames/30right*.png', '/Users/pplsuser/Desktop/All_frames/31right*.png', '/Users/pplsuser/Desktop/All_frames/32right*.png', '/Users/pplsuser/Desktop/All_frames/33right*.png', '/Users/pplsuser/Desktop/All_frames/34right*.png', '/Users/pplsuser/Desktop/All_frames/35right*.png', '/Users/pplsuser/Desktop/All_frames/36right*.png', '/Users/pplsuser/Desktop/All_frames/37right*.png', '/Users/pplsuser/Desktop/All_frames/38right*.png', '/Users/pplsuser/Desktop/All_frames/39right*.png', '/Users/pplsuser/Desktop/All_frames/40right*.png', '/Users/pplsuser/Desktop/All_frames/41right*.png', '/Users/pplsuser/Desktop/All_frames/42right*.png', '/Users/pplsuser/Desktop/All_frames/43right*.png', '/Users/pplsuser/Desktop/All_frames/44right*.png', '/Users/pplsuser/Desktop/All_frames/45right*.png', '/Users/pplsuser/Desktop/All_frames/46right*.png', '/Users/pplsuser/Desktop/All_frames/47right*.png', '/Users/pplsuser/Desktop/All_frames/48right*.png', '/Users/pplsuser/Desktop/All_frames/49right*.png', '/Users/pplsuser/Desktop/All_frames/50right*.png', '/Users/pplsuser/Desktop/All_frames/51right*.png', '/Users/pplsuser/Desktop/All_frames/52right*.png', '/Users/pplsuser/Desktop/All_frames/53right*.png', '/Users/pplsuser/Desktop/All_frames/54right*.png', '/Users/pplsuser/Desktop/All_frames/55right*.png', '/Users/pplsuser/Desktop/All_frames/56right*.png', '/Users/pplsuser/Desktop/All_frames/57right*.png', '/Users/pplsuser/Desktop/All_frames/58right*.png', '/Users/pplsuser/Desktop/All_frames/59right*.png', '/Users/pplsuser/Desktop/All_frames/60right*.png', '/Users/pplsuser/Desktop/All_frames/61right*.png', '/Users/pplsuser/Desktop/All_frames/62right*.png', '/Users/pplsuser/Desktop/All_frames/63right*.png']
    indexes_trans_right=['0right*.png', '1right*.png', '2right*.png', '3right*.png', '4right*.png', '5right*.png', '6right*.png', '7right*.png', '8right*.png', '9right*.png', '10right*.png', '11right*.png', '12right*.png', '13right*.png', '14right*.png', '15right*.png', '16right*.png', '17right*.png', '18right*.png', '19right*.png', '20right*.png', '21right*.png', '22right*.png', '23right*.png', '24right*.png', '25right*.png', '26right*.png', '27right*.png', '28right*.png', '29right*.png', '30right*.png', '31right*.png', '32right*.png', '33right*.png', '34right*.png', '35right*.png', '36right*.png', '37right*.png', '38right*.png', '39right*.png', '40right*.png', '41right*.png', '42right*.png', '43right*.png', '44right*.png', '45right*.png', '46right*.png', '47right*.png', '48right*.png', '49right*.png', '50right*.png', '51right*.png', '52right*.png', '53right*.png', '54right*.png', '55right*.png', '56right*.png', '57right*.png', '58right*.png', '59right*.png', '60right*.png', '61right*.png', '62right*.png', '63right*.png']
    #indexes_trans_left=['/Users/pplsuser/Desktop/All_frames/0left*.png', '/Users/pplsuser/Desktop/All_frames/1left*.png', '/Users/pplsuser/Desktop/All_frames/2left*.png', '/Users/pplsuser/Desktop/All_frames/3left*.png', '/Users/pplsuser/Desktop/All_frames/4left*.png', '/Users/pplsuser/Desktop/All_frames/5left*.png', '/Users/pplsuser/Desktop/All_frames/6left*.png', '/Users/pplsuser/Desktop/All_frames/7left*.png', '/Users/pplsuser/Desktop/All_frames/8left*.png', '/Users/pplsuser/Desktop/All_frames/9left*.png', '/Users/pplsuser/Desktop/All_frames/10left*.png', '/Users/pplsuser/Desktop/All_frames/11left*.png', '/Users/pplsuser/Desktop/All_frames/12left*.png', '/Users/pplsuser/Desktop/All_frames/13left*.png', '/Users/pplsuser/Desktop/All_frames/14left*.png', '/Users/pplsuser/Desktop/All_frames/15left*.png', '/Users/pplsuser/Desktop/All_frames/16left*.png', '/Users/pplsuser/Desktop/All_frames/17left*.png', '/Users/pplsuser/Desktop/All_frames/18left*.png', '/Users/pplsuser/Desktop/All_frames/19left*.png', '/Users/pplsuser/Desktop/All_frames/20left*.png', '/Users/pplsuser/Desktop/All_frames/21left*.png', '/Users/pplsuser/Desktop/All_frames/22left*.png', '/Users/pplsuser/Desktop/All_frames/23left*.png', '/Users/pplsuser/Desktop/All_frames/24left*.png', '/Users/pplsuser/Desktop/All_frames/25left*.png', '/Users/pplsuser/Desktop/All_frames/26left*.png', '/Users/pplsuser/Desktop/All_frames/27left*.png', '/Users/pplsuser/Desktop/All_frames/28left*.png', '/Users/pplsuser/Desktop/All_frames/29left*.png', '/Users/pplsuser/Desktop/All_frames/30left*.png', '/Users/pplsuser/Desktop/All_frames/31left*.png', '/Users/pplsuser/Desktop/All_frames/32left*.png', '/Users/pplsuser/Desktop/All_frames/33left*.png', '/Users/pplsuser/Desktop/All_frames/34left*.png', '/Users/pplsuser/Desktop/All_frames/35left*.png', '/Users/pplsuser/Desktop/All_frames/36left*.png', '/Users/pplsuser/Desktop/All_frames/37left*.png', '/Users/pplsuser/Desktop/All_frames/38left*.png', '/Users/pplsuser/Desktop/All_frames/39left*.png', '/Users/pplsuser/Desktop/All_frames/40left*.png', '/Users/pplsuser/Desktop/All_frames/41left*.png', '/Users/pplsuser/Desktop/All_frames/42left*.png', '/Users/pplsuser/Desktop/All_frames/43left*.png', '/Users/pplsuser/Desktop/All_frames/44left*.png', '/Users/pplsuser/Desktop/All_frames/45left*.png', '/Users/pplsuser/Desktop/All_frames/46left*.png', '/Users/pplsuser/Desktop/All_frames/47left*.png', '/Users/pplsuser/Desktop/All_frames/48left*.png', '/Users/pplsuser/Desktop/All_frames/49left*.png', '/Users/pplsuser/Desktop/All_frames/50left*.png', '/Users/pplsuser/Desktop/All_frames/51left*.png', '/Users/pplsuser/Desktop/All_frames/52left*.png', '/Users/pplsuser/Desktop/All_frames/53left*.png', '/Users/pplsuser/Desktop/All_frames/54left*.png', '/Users/pplsuser/Desktop/All_frames/55left*.png', '/Users/pplsuser/Desktop/All_frames/56left*.png', '/Users/pplsuser/Desktop/All_frames/57left*.png', '/Users/pplsuser/Desktop/All_frames/58left*.png', '/Users/pplsuser/Desktop/All_frames/59left*.png', '/Users/pplsuser/Desktop/All_frames/60left*.png', '/Users/pplsuser/Desktop/All_frames/61left*.png', '/Users/pplsuser/Desktop/All_frames/62left*.png', '/Users/pplsuser/Desktop/All_frames/63left*.png']
    indexes_trans_left=['0left*.png', '1left*.png', '2left*.png', '3left*.png', '4left*.png', '5left*.png', '6left*.png', '7left*.png', '8left*.png', '9left*.png', '10left*.png', '11left*.png', '12left*.png', '13left*.png', '14left*.png', '15left*.png', '16left*.png', '17left*.png', '18left*.png', '19left*.png', '20left*.png', '21left*.png', '22left*.png', '23left*.png', '24left*.png', '25left*.png', '26left*.png', '27left*.png', '28left*.png', '29left*.png', '30left*.png', '31left*.png', '32left*.png', '33left*.png', '34left*.png', '35left*.png', '36left*.png', '37left*.png', '38left*.png', '39left*.png', '40left*.png', '41left*.png', '42left*.png', '43left*.png', '44left*.png', '45left*.png', '46left*.png', '47left*.png', '48left*.png', '49left*.png', '50left*.png', '51left*.png', '52left*.png', '53left*.png', '54left*.png', '55left*.png', '56left*.png', '57left*.png', '58left*.png', '59left*.png', '60left*.png', '61left*.png', '62left*.png', '63left*.png']
    list_transitive_combinations_zip_left=zip(list_transitive_combinations_all64,indexes_trans_left)
    list_transitive_combinations_zip_right=zip(list_transitive_combinations_all64,indexes_trans_right)
    zip_trans=zip(list_transitive_combinations_zip_left,list_transitive_combinations_zip_right)
    zip_int=zip(list_intransitive_combinations_zip_left,list_intransitive_combinations_zip_right)
    list_test=zip_trans+zip_int
    list_testing=zip(list_test,hol_tags_spaces_with_index)
    zip_trans_tag=list_testing[:64]
    zip_int_tag=list_testing[64:]
    list_training=[]
    if generation == '0':
        random_trans=random.sample(zip_trans_tag,32) 
        while thingy(dim_trans,random_trans)!=28:
            random_trans=random.sample(zip_trans_tag,32)
        random_int=random.sample(zip_int_tag,8) 
        while thingy(dim_int,random_int)!=10:
            random_int=random.sample(zip_int_tag,8)
        list_training=random_trans+random_int
    elif generation != '0':
        for i in list_testing:
            if i[1][0] != '':
                list_training.append(i)
    print len(list_training) 
    
    list_testing_trans=random.sample(zip_trans_tag,32)    
    list_testing_int=random.sample(zip_int_tag,8)    
    while thingy(dim_int,list_testing_int)!=10:
        list_testing_int=random.sample(zip_int_tag,8)
    while thingy(dim_trans,list_testing_trans)!=28:
        list_testing_trans=random.sample(zip_trans_tag,32)
    other_list_testing_int=[]
    for other_int in zip_int_tag:
        if other_int not in list_testing_int:
            other_list_testing_int.append(other_int)
    other_list_testing_trans=[]
    for other_trans in zip_trans_tag:
        if other_trans not in list_testing_trans:
            other_list_testing_trans.append(other_trans)
    list_testing_server=list_testing_trans+list_testing_int
    list_testing_client=other_list_testing_trans+other_list_testing_int
    #list_server_to_save=[u[1][1] for u in list_testing_server]         
    #list_client_to_save=[u[1][1] for u in list_testing_client]
    #save_test_list(list_server_to_save,chain, generation+1,'server')
    #save_test_list(list_client_to_save,chain, generation+1,'client')      
    #list_training=list_training_trans+list_training_int
    return [list_training,list_testing_server,list_testing_client]

def allUnique(x):
    seen = list()
    return not any(i in seen or seen.append(i) for i in x)
    
def chunks(s, n):
    """Produce `n`-character chunks from `s`."""
    for start in range(0, len(s), n):
        yield s[start:start+n]

def split_text(s):
    if len(s.split())>1:
        l=[]
        for span in range(1,len(s.split())):    
            words = s.split(' ')
            list_text= [" ".join(words[i:i+span]) for i in range(0, len(words), span)]
            n=0
            for i in list_text[:-1]:        
                if len(i) <19:
                    n+=1
            #print n
            #print 'l:', len(list_text[:-1])
            if n==len(list_text[:-1]):
                l=list_text
        segmented='\n'.join(l)
    elif len(s.split())==1:
        seg=[]
        for i in chunks(s,19):
            seg.append(i)
        segmented='\n'.join(seg)    
    elif len(s.split())==0:
        segmented=s
        
    return segmented

def scenes_0scene_1foil_2tag_3index_4scenedelete_56otherfoils(t_list,fixed_list,starting_pos):
    
    pos_alt=[]
    for i in range(3):
        pos_alt.append(random.choice([0,1]))
    
    file_name1=random.choice(t_list)[0][pos_alt[0]]
    file_name2=random.choice(t_list)[0][pos_alt[1]]
    file_name3=random.choice(t_list)[0][pos_alt[2]]  
    
    scene_to_delete=random.choice(fixed_list)
    scene_tag=scene_to_delete[1][0]
    scene_index=scene_to_delete[1][1]
    if starting_pos=='left':
        scene=scene_to_delete[0][0]
    elif starting_pos=='right':
        scene=scene_to_delete[0][1]
    while allUnique([scene[0],file_name1[0],  file_name2[0],file_name3[0]])==False:           
    #while scene_to_delete[0][0][1] in [file_name1[1],file_name2[1],file_name3[1]] or scene_to_delete[0][1][1] in [file_name1[1],file_name2[1],file_name3[1]]:
        file_name1=random.choice(t_list)[0][pos_alt[0]]
        file_name2=random.choice(t_list)[0][pos_alt[1]]
        file_name3=random.choice(t_list)[0][pos_alt[2]]

    return scene, file_name1, scene_tag, scene_index, scene_to_delete, file_name2, file_name3
    
def save_test_list(test_list,chain,generation):
    outfile="./Test_list_%d_%s.txt"%(chain,generation)
    with open(outfile, 'wb') as f:
        pickle.dump(test_list, f)     
    
    f.close()
    
def read_test_list(chain,generation):
    outfile="./Test_list_%d_%s.txt"%(chain,generation)
    with open(outfile, 'rb') as f:
        test_list=pickle.load(f)
    return test_list       

    
list_leven=[]
#a routine to save responses to file anytime we want to
def saveThisResponse(captured_string,leven, target_string,list_leven,ID,chain,myRole):
    outfile = "./Dyads_%d_%s_%sResponses.txt"%(chain,ID,myRole)
    f = open(outfile, 'a') #open our results file in append mode so we don't overwrite anything
    f.write(captured_string) #write the string they typed    
    f.write('; typed at %s' %time.asctime()) #write a timestamp (very course)
    f.write(' Target: %s' %target_string)
    f.write(' Levenshtein distance:%s'%leven)
    f.write(' Accumulator: [')
    for item in list_leven:
        f.write('%s, '%item)
    f.write(']')
    f.write('\n') # write a line ending
    f.close() #close and "save" the output file

def saveResponse_xls(captured_string,leven, target_string, list_leven, ID,chain,number_trial,myRole):
    if number_trial == 0:
        wbk=xlwt.Workbook()
        responses_sheet=wbk.add_sheet('Dyads_Exp_%d_%s_%s'%(chain,ID,myRole))
        responses_sheet.write(number_trial,0, target_string)
        responses_sheet.write(number_trial,1, captured_string)
        responses_sheet.write(number_trial,2, '%s'%leven)
        responses_sheet.write(number_trial,3,time.asctime())
        wbk.save('Dyads_Exp_%d_%s_%s.xls'%(chain,ID,myRole))
    else:
        rb=open_workbook('Dyads_Exp_%d_%s_%s.xls'%(chain,ID,myRole))
        #r_sheet=rb.sheet_by_index(0)
        wb=copy(rb)
        w_sheet=wb.get_sheet(0)
        w_sheet.write(number_trial,0, target_string)
        w_sheet.write(number_trial,1, captured_string)
        w_sheet.write(number_trial,2, '%s'%leven)
        w_sheet.write(number_trial,3,time.asctime())
        wb.save('Dyads_Exp_%d_%s_%s.xls'%(chain,ID,myRole))
        
def iterated_output(captured_string, ID,chain, number_list,number_trial,myRole):
    #if myRole=='server':
        if number_trial == 120 or number_trial ==121:
            if chain==0:
                wbk=xlwt.Workbook()        
                responses_sheet1=wbk.add_sheet('ChainI_%s'%ID)
                wbk.add_sheet('ChainII_%s'%ID)
                wbk.add_sheet('ChainIII_%s'%ID)
                wbk.add_sheet('ChainIV_%s'%ID)                   
                responses_sheet1.write(number_list,0, captured_string) 
            else:
                wb=open_workbook('Iterated_output_dyads_%s_%s.xls'%(ID,myRole))
                wbk=copy(wb)
                sheet=wbk.get_sheet(chain)
                sheet.write(number_list,0, captured_string)       
            wbk.save('Iterated_output_dyads_%s_%s.xls'%(ID,myRole))
        else:        
            rb=open_workbook('Iterated_output_dyads_%s_%s.xls'%(ID,myRole))
            #r_sheet=rb.sheet_by_index(0)
            wb=copy(rb)                  
            w_sheet=wb.get_sheet(chain)               
            w_sheet.write(number_list,0, captured_string)
            wb.save('Iterated_output_dyads_%s_%s.xls'%(ID,myRole))
    #else:
    #    pass

#get cells form file: x=open_workbook('name.xls')
#x.sheets()[num_sheet].cell_value(row,col)

def append_to_file(text,ID,chain,myRole):
    outfile = "./Dyads_%d_%s_%sResponses.txt"%(chain,ID,myRole)
    f = open(outfile, 'a') #open our results file in append mode so we don't overwrite anything
    f.write(text)
    f.write('\n') # write a line ending
    f.close() #close and "save" the output file
    
def append_to_file_xls(text,ID,chain,number_trial,myRole):
    rb=open_workbook('Dyads_Exp_%d_%s_%s.xls'%(chain,ID,myRole))
    #r_sheet=rb.sheet_by_index(0)
    wb=copy(rb)
    w_sheet=wb.get_sheet(0)
    w_sheet.write(number_trial, 1, text)
    w_sheet.write(number_trial, 3, '%s' %time.asctime())
    wb.save('Dyads_Exp_%d_%s_%s.xls'%(chain,ID,myRole))


#calculates the levenshtein distance
def levenshtein(str1, str2):
  d=dict()
  for i in range(len(str1)+1):
     d[i]=dict()
     d[i][0]=i
  for i in range(len(str2)+1):
     d[0][i] = i
  for i in range(1, len(str1)+1):
     for j in range(1, len(str2)+1):
        d[i][j] = min(d[i][j-1]+1, d[i-1][j]+1, d[i-1][j-1]+(not str1[i-1] == str2[j-1]))
  return d[len(str1)][len(str2)]
  
def allow_typing(myWin, ID,chain, target_string,number_trial,number_list,part,myRole,socket,role):
    sans = ['Gill Sans MT', 'Arial','Helvetica','Verdana'] #use the first font found on this list
    CapturedResponseString = visual.TextStim(myWin, units='norm',height = 0.1,
                pos=(0, 0), text='',
                font=sans, 
                alignHoriz = 'center',alignVert='center',
                color='black')
    # now we will keep tracking what's happening on the keyboar until the participant hits the return key    
    captured_string = '' #empty for now.. this is a string of zero length that 
    # we will append our key presses to in sequence
    subject_response_finished = 0 # only changes when they hit return

    #check for Esc key / return key presses each frame
    while subject_response_finished == 0:
        for key in event.getKeys():
            #quit at any point
            if key in ['escape']: 
                myWin.close()
                core.quit()
            
            #if the participant hits return, save the string so far out 
            #and reset the string to zero length for the next trial
            elif key in ['return']:
                if captured_string != '':
                    captured_string=captured_string.strip()  
                    if len(target_string) != 0:
                        leven=levenshtein(captured_string,target_string)
                    elif len(target_string) == 0:
                        leven='NA'
                    list_leven.append(leven)
                    print 'participant typed %s' %captured_string #show in debug window
                    print 'Levenshtein: %s'%str(leven)
                    print list_leven
                    saveThisResponse(captured_string, str(leven), target_string,list_leven, ID,chain,myRole) #write to file
                    saveResponse_xls(captured_string,str(leven), target_string, list_leven, ID,chain,number_trial,myRole)
                    
                    if part=='second_part':
                        iterated_output(captured_string,ID, chain, number_list,number_trial,myRole)                        
                        send_a_message(captured_string,socket)
                        print 'sender typed:',captured_string
                    captured_string = '' #reset to zero length 
                    subject_response_finished = 1 #allows the next trial to start
                else:
                    event.clearEvents(eventType='keyboard')

                                  

            
            #allow the participant to do deletions too , using the 
            # delete key, and show the change they made
            elif key in ['delete','backspace']:
                captured_string = captured_string[:-1]+'_' #delete last character
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
                captured_string=captured_string[:-1]
            #handle spaces
            elif key in ['space']:
                captured_string = captured_string+' _'                
                #show it
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
                captured_string=captured_string[:-1]                
            #elif key in ['period']:
            #    captured_string = captured_string+'.'
            #    #show it
            #    CapturedResponseString.setText(captured_string)
            #    CapturedResponseString.draw()
            #    myWin.flip()
            #elif key in ['comma']:
            #    captured_string = captured_string+','
            #    #show it
            #    CapturedResponseString.setText(captured_string)
            #    CapturedResponseString.draw()
            #    myWin.flip()
            elif key not in ['space','delete','backsapce','return','scape','a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'l', 'm', 'n', 'o', 'p', 'r', 't', 'u', 'v']:
                pass #do nothing when some keys are pressed
            #etc ...
            #if any other key is pressed, add it to the string and 
            # show the participant what they typed
            else:                 
                captured_string = captured_string+key+'_'
                #show it
                CapturedResponseString.setColor('DimGray')
                CapturedResponseString.setText(captured_string)
                CapturedResponseString.draw()
                myWin.flip()
                captured_string=captured_string[:-1]

def discrimination_task(myWin, scene, foil, chain, ID, number_trial,myRole,texto,part,socket,path):
        pos_alt=[[-0.5,0],[0.5,0]]
        index_alt=random.choice([0,1])
        pos_alt1=pos_alt[index_alt]
        if index_alt==0:
            pos_alt2=pos_alt[1]
        else:
            pos_alt2=pos_alt[0]
        box_alt1= visual.Rect(myWin, units='norm', width=0.85, height=0.7, pos=pos_alt1, lineColor='DimGray')
        box_alt2= visual.Rect(myWin, units='norm', width=0.85, height=0.7, pos=pos_alt2, lineColor='DimGray') 
        left_arrow=visual.ImageStim(myWin, image=path+'f_key.png', units='norm', size=[0.15,0.15],pos=[-0.5,-0.55],flipHoriz=False,flipVert=False,autoLog=True)
        right_arrow=visual.ImageStim(myWin, image=path+'j_key.png', units='norm', size=[0.15,0.15],pos=[0.5,-0.55],flipHoriz=False,flipVert=False,autoLog=True)
        text1=texto+'?'
        tag_alt=visual.TextStim(myWin, units='norm', color='black',pos=[0,0.5], text=text1)
        box_alt1.setAutoDraw(True)
        box_alt2.setAutoDraw(True)
        left_arrow.setAutoDraw(True)
        right_arrow.setAutoDraw(True)
        timer=core.CountdownTimer(180)
        image_alt1_list=[]
        image_alt2_list=[]
        for image_alt1_name in glob.glob(path+scene[1]): image_alt1_list.append(image_alt1_name)#Image.open(open(image_alt1_name,'rb')))
        for image_alt2_name in glob.glob(path+foil[1]): image_alt2_list.append(image_alt2_name)#Image.open(open(image_alt2_name,'rb')))
        
        #for i in image_alt1_list: i.load()
        #for i in image_alt2_list: i.load()

        if 'perfective' in scene[0]:
            more_frames= image_alt1_list[-1:]
            for i in range(44):
                for frame in more_frames: image_alt1_list.append(frame)
        elif 'perfective' in foil[0]:
            more_frames= image_alt2_list[-1:]
            for i in range(44):
                for frame in more_frames: image_alt2_list.append(frame)
        if len(image_alt1_list)>len(image_alt2_list):
            if 'perfective' in foil[0]:
                repeat_frame=image_alt2_list[-1:]
            else:
                repeat_frame=image_alt2_list[:len(image_alt1_list)-len(image_alt2_list)]
            for num_add in range(len(image_alt1_list)-len(image_alt2_list)):
                for frame in repeat_frame: image_alt2_list.append(frame)
        elif len(image_alt2_list)>len(image_alt1_list):
            if 'perfective' in scene[0]:
                repeat_frame=image_alt1_list[-1:]
            else:
                repeat_frame=image_alt1_list[:len(image_alt2_list)-len(image_alt1_list)]            
            for num_add in range(len(image_alt2_list)-len(image_alt1_list)):
                for frame in repeat_frame: image_alt1_list.append(frame)
        image_alt_list=zip(image_alt1_list, image_alt2_list)
        while timer.getTime() >0:
            for image_alt in image_alt_list:
                    pre_draw=timer.getTime()
                    image_alt1= visual.ImageStim(myWin, image_alt[0], units='norm', size=[0.8, 0.8], pos=pos_alt1,flipHoriz=False,flipVert=False,autoLog=True)
                    image_alt2= visual.ImageStim(myWin, image_alt[1], units='norm', size=[0.8,0.8], pos=pos_alt2, flipHoriz=False,flipVert=False,autoLog=True)
                    tag_alt.draw()
                    image_alt1.draw()
                    image_alt2.draw()
                    myWin.flip()
                    after_draw=timer.getTime()
                    dif=pre_draw-after_draw
                    #print dif
                    #print timer.getTime()
                    #if abs(dif)<0.07:
                    core.wait(0.08-abs(dif))
                    #print pre_draw-timer.getTime()
                    if event.getKeys(['escape']):
                        myWin.close()
                        core.quit()
                    if event.getKeys(['f']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1[0]==-0.5:
                            append_to_file_xls('Correct', ID,chain,number_trial,myRole)
                            append_to_file('Correct', ID,chain,myRole)
                            if part=='second_part':
                                mens=['Communication was successful!',scene,pos_alt1,pos_alt2,texto]
                                send_a_message(str(mens),socket) 
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                left_arrow.setAutoDraw(False)
                                right_arrow.setAutoDraw(False)
                                feedback_message(myWin,'Communication was successful!',scene,pos_alt1,pos_alt2,texto,path)                   
                         else:
                            append_to_file_xls('Wrong', ID,chain,number_trial,myRole)
                            append_to_file('Wrong', ID,chain,myRole)
                            if part=='second_part':
                                mens=['Sorry! Communication failed.',scene,pos_alt1,pos_alt2,texto]
                                send_a_message(str(mens),socket)
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                left_arrow.setAutoDraw(False)
                                right_arrow.setAutoDraw(False)
                                feedback_message(myWin,'Sorry! Communication failed.',scene,pos_alt1,pos_alt2,texto,path)  
                         break
                    elif event.getKeys(['j']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1[0]==0.5: 
                            append_to_file('Correct', ID,chain,myRole)                    
                            append_to_file_xls('Correct',ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Communication was successful!',scene,pos_alt1,pos_alt2,texto]
                                send_a_message(str(mens),socket)                                
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                left_arrow.setAutoDraw(False)
                                right_arrow.setAutoDraw(False)
                                feedback_message(myWin,'Communication was successful!',scene,pos_alt1,pos_alt2,texto,path)                              
                              
                          
                         else:
                            append_to_file('Wrong', ID,chain,myRole)
                            append_to_file_xls('Wrong', ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Sorry! Communication failed.',scene,pos_alt1,pos_alt2,texto]
                                send_a_message(str(mens),socket)
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                left_arrow.setAutoDraw(False)
                                right_arrow.setAutoDraw(False)
                                feedback_message(myWin,'Sorry! Communication failed.',scene,pos_alt1,pos_alt2,texto,path)  
                         break
        #for image_alt1_name in glob.glob(path+scene[1]): open(image_alt1_name,'rb').close()
        #for image_alt2_name in glob.glob(path+foil[1]): open(image_alt2_name,'rb').close()
        box_alt1.setAutoDraw(False)
        box_alt2.setAutoDraw(False)
        left_arrow.setAutoDraw(False)
        right_arrow.setAutoDraw(False)

def discrimination_task_testing(myWin, scene, foil1, foil2, foil3, chain, ID, number_trial,myRole,texto,part,socket,path,role):
        pos_alt=[[-0.6,0.6],[0.6,0.6],[-0.6,-0.4],[0.6,-0.4]]
        index_alt=random.choice([0,1,2,3])
        pos_alt1=pos_alt[index_alt]
        pos_big_scene=list(map(mul,pos_alt1,[1,0]))
        pos_big_foil=list(map(mul,pos_alt1,[-1,0]))
        if pos_big_scene[0]<0:
            pos_big_scene[0]=-0.5
            pos_big_foil[0]=0.5
        else:
            pos_big_scene[0]=0.5
            pos_big_foil[0]=-0.5
        pos_alt.remove(pos_alt1)
        box_alt1= visual.Rect(myWin, units='norm', width=0.60, height=0.55, pos=pos_alt1, lineColor='DimGray')
        box_alt2= visual.Rect(myWin, units='norm', width=0.60, height=0.55, pos=pos_alt[0], lineColor='DimGray')
        box_alt3= visual.Rect(myWin, units='norm', width=0.60, height=0.55, pos=pos_alt[1], lineColor='DimGray') 
        box_alt4= visual.Rect(myWin, units='norm', width=0.60, height=0.55, pos=pos_alt[2], lineColor='DimGray')  
        left_arrow_top=visual.ImageStim(myWin, image=path+'computer_key_F.png', units='norm', size=[0.15,0.15],pos=[-0.6,0.15],flipHoriz=False,flipVert=False,autoLog=True)
        right_arrow_top=visual.ImageStim(myWin, image=path+'computer_key_J.png', units='norm', size=[0.15,0.15],pos=[0.6,0.15],flipHoriz=False,flipVert=False,autoLog=True)
        left_arrow_bottom=visual.ImageStim(myWin, image=path+'computer_key_V.png', units='norm', size=[0.15,0.15],pos=[-0.6,-0.85],flipHoriz=False,flipVert=False,autoLog=True)
        right_arrow_bottom=visual.ImageStim(myWin, image=path+'computer_key_N.png', units='norm', size=[0.15,0.15],pos=[0.6,-0.85],flipHoriz=False,flipVert=False,autoLog=True)
        #texto_split=split_text(texto)
        #text1='Your partner typed:\n'+texto_split 
        text1=texto       
        tag_alt=visual.TextStim(myWin, units='norm', color='black',pos=[0,0], text=text1)
        box_alt1.setAutoDraw(True)
        box_alt2.setAutoDraw(True)
        box_alt3.setAutoDraw(True)
        box_alt4.setAutoDraw(True)
        left_arrow_top.setAutoDraw(True)
        right_arrow_top.setAutoDraw(True)
        left_arrow_bottom.setAutoDraw(True)
        right_arrow_bottom.setAutoDraw(True)
        timer=core.CountdownTimer(180)
        image_alt1_list=[]
        image_alt2_list=[]
        image_alt3_list=[]
        image_alt4_list=[]
        for image_alt1_name in glob.glob(path+scene[1]): image_alt1_list.append(Image.open(open(image_alt1_name,'rb')))
        for image_alt2_name in glob.glob(path+foil1[1]): image_alt2_list.append(Image.open(open(image_alt2_name,'rb')))
        for image_alt3_name in glob.glob(path+foil2[1]): image_alt3_list.append(Image.open(open(image_alt3_name,'rb')))
        for image_alt4_name in glob.glob(path+foil3[1]): image_alt4_list.append(Image.open(open(image_alt4_name,'rb')))
        
        for i in image_alt1_list: i.load()
        for i in image_alt2_list: i.load()
        for i in image_alt3_list: i.load()
        for i in image_alt4_list: i.load()
        if 'perfective' in scene[0]:
            more_frames= image_alt1_list[-1:]
            for i in range(44):
                for frame in more_frames: image_alt1_list.append(frame)
        elif 'perfective' in foil1[0]:
            more_frames= image_alt2_list[-1:]
            for i in range(44):
                for frame in more_frames: image_alt2_list.append(frame)
        elif 'perfective' in foil2[0]:
            more_frames= image_alt3_list[-1:]
            for i in range(44):
                for frame in more_frames: image_alt3_list.append(frame)
        elif 'perfective' in foil3[0]:
            more_frames= image_alt4_list[-1:]
            for i in range(44):
                for frame in more_frames: image_alt4_list.append(frame)                
        list_images=[image_alt1_list,image_alt2_list, image_alt3_list, image_alt4_list]
        max_len=len(max(list_images,key=len))
        foil_number=-1
        for thingy in list_images:
            foil_number+=1   
            foil_list=[scene,foil1,foil2,foil3]       
            if max_len>len(thingy):                
                if 'perfective' in foil_list[foil_number][0]:
                    repeat_frame=thingy[-1:]
                    for num_add in range(max_len-len(thingy)):                    
                        thingy.append(repeat_frame[0])
                else:
                    repeat_frame=thingy[:max_len-len(thingy)]
                    thingy=thingy+repeat_frame
 
                          
        foils=[foil1,foil2,foil3]      
        image_alt_list=zip(image_alt1_list, image_alt2_list,image_alt3_list,image_alt4_list)
        while timer.getTime() >0:
            for image_alt in image_alt_list:
                    pre_draw=timer.getTime()
                    #print pre_draw
                    image_alt1= visual.ImageStim(myWin, image_alt[0], units='norm', size=[0.6, 0.6], pos=pos_alt1,flipHoriz=False,flipVert=False,autoLog=True)
                    image_alt2= visual.ImageStim(myWin, image_alt[1], units='norm', size=[0.6,0.6], pos=pos_alt[0], flipHoriz=False,flipVert=False,autoLog=True)
                    image_alt3= visual.ImageStim(myWin, image_alt[2], units='norm', size=[0.6,0.6], pos=pos_alt[1], flipHoriz=False,flipVert=False,autoLog=True)
                    image_alt4= visual.ImageStim(myWin, image_alt[3], units='norm', size=[0.6,0.6], pos=pos_alt[2], flipHoriz=False,flipVert=False,autoLog=True)
                    tag_alt.draw()
                    image_alt1.draw()
                    image_alt2.draw()
                    image_alt3.draw()
                    image_alt4.draw()
                    myWin.flip()
                    after_draw=timer.getTime()
                    dif=after_draw-pre_draw
                    #print dif
                    #print timer.getTime()
                    #if abs(dif)<0.07:
                    core.wait(0.08-abs(dif))
                    #print pre_draw-timer.getTime()
                    if event.getKeys(['escape']):
                        myWin.close()
                        core.quit()
                    if event.getKeys(['f']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1==[-0.6,0.6]:
                            press_foil='' 
                            append_to_file_xls('Correct', ID,chain,number_trial,myRole)
                            append_to_file('Correct', ID,chain,myRole)
                            if part=='second_part':
                                mens=['Success!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket) 
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Success!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)                   
                         else:
                            press=pos_alt.index([-0.6,0.6])
                            press_foil=foils[press]
                            append_to_file_xls('Wrong', ID,chain,number_trial,myRole)
                            append_to_file('Wrong', ID,chain,myRole)
                            if part=='second_part':
                                mens=['Sorry!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket)
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Sorry!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)  
                         break
                    elif event.getKeys(['j']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1==[0.6,0.6]:
                            press_foil=''  
                            append_to_file('Correct', ID,chain,myRole)                    
                            append_to_file_xls('Correct',ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Success!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket)                                
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Success!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)                              
                              
                          
                         else:
                            press=pos_alt.index([0.6,0.6])
                            press_foil=foils[press]
                            append_to_file('Wrong', ID,chain,myRole)
                            append_to_file_xls('Wrong', ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Sorry!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket)
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Sorry!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)  
                         break
                    elif event.getKeys(['v']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1==[-0.6,-0.4]:
                            press_foil=''  
                            append_to_file('Correct', ID,chain,myRole)                    
                            append_to_file_xls('Correct',ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Success!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket)                                
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Success!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)                             
                                                      
                         else:
                            press=pos_alt.index([-0.6,-0.4])
                            press_foil=foils[press]
                            append_to_file('Wrong', ID,chain,myRole)
                            append_to_file_xls('Wrong', ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Sorry!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket)
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Sorry!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)  
                         break
                    elif event.getKeys(['n']):
                         timer=core.CountdownTimer(0)
                         if pos_alt1==[0.6,-0.4]:
                            press_foil=''  
                            append_to_file('Correct', ID,chain,myRole)                    
                            append_to_file_xls('Correct',ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Success!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket)                                
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Success!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)                             
                                                      
                         else:
                            press=pos_alt.index([0.6,-0.4])
                            press_foil=foils[press]
                            append_to_file('Wrong', ID,chain,myRole)
                            append_to_file_xls('Wrong', ID,chain,number_trial,myRole)
                            if part=='second_part':
                                mens=['Sorry!',scene,pos_big_scene,pos_big_foil,texto,press_foil]
                                send_a_message(str(mens),socket)
                                box_alt1.setAutoDraw(False)
                                box_alt2.setAutoDraw(False)
                                box_alt3.setAutoDraw(False)
                                box_alt4.setAutoDraw(False)
                                left_arrow_top.setAutoDraw(False)
                                right_arrow_top.setAutoDraw(False)
                                left_arrow_bottom.setAutoDraw(False)
                                right_arrow_bottom.setAutoDraw(False)
                                feedback_message(myWin,'Sorry!',scene,pos_big_scene,pos_big_foil,texto,path,press_foil,role)  
                         break
                         
        for image_alt1_name in glob.glob(path+scene[1]): open(image_alt1_name,'rb').close()
        for image_alt2_name in glob.glob(path+foil1[1]): open(image_alt2_name,'rb').close()
        for image_alt3_name in glob.glob(path+foil2[1]): open(image_alt3_name,'rb').close()
        for image_alt4_name in glob.glob(path+foil3[1]): open(image_alt4_name,'rb').close()                 
                         
        box_alt1.setAutoDraw(False)
        box_alt2.setAutoDraw(False)
        box_alt3.setAutoDraw(False)
        box_alt4.setAutoDraw(False)
        left_arrow_top.setAutoDraw(False)
        right_arrow_top.setAutoDraw(False)
        left_arrow_bottom.setAutoDraw(False)
        right_arrow_bottom.setAutoDraw(False)

def bounce(myWin, list_targets,color, shape, number, aspect,text_tag, starting_pos,ID):
    if number=='singular':
        flipy=0.074
    else:
        flipy=0.06
    timer=core.CountdownTimer(5)    
    frame=0
    if starting_pos=='left':        
        start_pos=[[-0.4,0.4,0.05],[-0.4,0.4,0.05]]
        polarity=1
    else:
        start_pos=[[0.4,-0.4,-0.05],[0.4,-0.4,-0.05]]
        polarity=-1
        
    target=list_targets[0]
    target1=list_targets[1]
    target2=list_targets[2]
    target3=list_targets[3]
    target4=list_targets[4]
    target5=list_targets[5]
    target6=list_targets[6]
    target7=list_targets[7]
    target8=list_targets[8]
    if aspect=='perfective':
        if number=='singular':
            target.setAutoDraw(True)
            
            for i in np.arange(start_pos[0][0],start_pos[0][1],start_pos[0][2]):
                frame+=1
                if frame%2==0:
                    z=0
                else:
                    z=0.15                                   
                target.setPos([i,z])                            
                myWin.flip()
                #myWin.getMovieFrame()
                core.wait(flipy)
            core.wait(5.-flipy*16)                
        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)            
            for i in np.arange(start_pos[1][0],start_pos[1][1],start_pos[1][2]):
                frame+=1
                if frame%2==0:
                    z=0
                    y=-0.1
                else:
                    z=0.15 
                    y=0.14
                                   
                target1.setPos([(-0.06*polarity)+i,0.15+z])
                target4.setPos([(0.3*polarity)+i, -0.2+z])
                target6.setPos([(-0.14*polarity)+i, 0+z])
                target8.setPos([(-0.1*polarity)+i,-0.15+z])
                #myWin.flip()
                #myWin.getMovieFrame()
                #core.wait(0.05)
                
                target.setPos([i, y])
                target2.setPos([(0.06*polarity)+i, -0.18+y])
                target3.setPos([(0.1*polarity)+i,0.15+y])
                target5.setPos([(0.2*polarity)+i, -0.06+y])
                target7.setPos([(0.24*polarity)+i, 0.24+y])                     
                myWin.flip()
                #myWin.getMovieFrame()
                core.wait(flipy)
                #for x in [-0.03,0.055]: 
                #     target.setPos([i, y])
                #     target2.setPos([(0.06*polarity)+i, -0.18+x])
                #     #target3.setPos([(0.1*polarity)+i,0.15+x])
                #     target5.setPos([(0.2*polarity)+i, -0.06+x])
                #     #target7.setPos([(0.24*polarity)+i, 0.24+x])                     
                #     myWin.flip()
                #     myWin.getMovieFrame()
                #     core.wait(0.05)
            core.wait(5.-flipy*16)
    else:
        if number=='singular':
            target.setAutoDraw(True)
            while timer.getTime()>0:
                                  
                    for i in np.arange(start_pos[0][0], start_pos[0][1],start_pos[0][2]):
                        pre_draw=timer.getTime()
                        frame+=1
                        if frame%2==0:
                            z=0
                        else:
                            z=0.15
                    #for z in [0,0.05]:                            
                        target.setPos([i, z])
                        myWin.flip()
                        #myWin.getMovieFrame()
                        core.wait(flipy)
                        #print pre_draw-timer.getTime()
                    for i in np.arange(-start_pos[0][0]-(0.1*polarity),-start_pos[0][1],-start_pos[0][2]):
                        frame+=1
                        if frame%2==0:
                            z=0
                        else:
                            z=0.15
                    #for z in [0,0.05]:                            
                        target.setPos([i, z])
                        myWin.flip()
                        #myWin.getMovieFrame()
                        core.wait(flipy)
        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)
            while timer.getTime()>0:
                    
                #for t in range(1,3):
                    for i in np.arange(start_pos[1][0], start_pos[1][1],start_pos[1][2]):
                        pre_draw=timer.getTime()
                        frame+=1
                        if frame%2==0:
                            z=0
                            y=-0.1
                        else:
                            z=0.15 
                            y=0.14
                    #for z in [0,0.05]:                            
                        target1.setPos([(-0.06*polarity)+i,0.15+z])
                        target4.setPos([(0.3*polarity)+i, -0.2+z])
                        target6.setPos([(-0.14*polarity)+i, 0+z])
                        target8.setPos([(-0.1*polarity)+i,-0.15+z])
                        #myWin.flip()
                        #myWin.getMovieFrame()
                        #core.wait(0.05)
                    #for y in [-0.05,0.045]:                             
                        target.setPos([i, y])
                        target2.setPos([(0.06*polarity)+i, -0.18+y])
                        target3.setPos([(0.1*polarity)+i,0.15+y])
                        target5.setPos([(0.2*polarity)+i, -0.06+y])
                        target7.setPos([(0.24*polarity)+i, 0.24+y])                         
                        myWin.flip()                        
                        #myWin.getMovieFrame()
                        core.wait(flipy)
                        #print pre_draw-timer.getTime()
                    for i in np.arange(-start_pos[1][0]-(0.1*polarity),-start_pos[1][1],-start_pos[1][2]):
                        frame+=1
                        if frame%2==0:
                            z=0
                            y=-0.1
                        else:
                            z=0.15 
                            y=0.14
                    #for z in [0,0.05]:                            
                        target1.setPos([(-0.06*polarity)+i,0.15+z])
                        target4.setPos([(0.3*polarity)+i, -0.2+z])
                        target6.setPos([(-0.14*polarity)+i, 0+z])                        
                        target8.setPos([(-0.1*polarity)+i,-0.15+z])
                        #myWin.flip()
                        #myWin.getMovieFrame()
                        #core.wait(0.05)
                    #for y in [-0.05,0.045]:                             
                        target.setPos([i, y])
                        target2.setPos([(0.06*polarity)+i, -0.18+y])
                        target3.setPos([(0.1*polarity)+i,0.15+y])
                        target5.setPos([(0.2*polarity)+i, -0.06+y])
                        target7.setPos([(0.24*polarity)+i, 0.24+y])                         
                        myWin.flip()
                        #myWin.getMovieFrame()
                        core.wait(flipy)
    for item_target in list_targets[:]:
        item_target.setAutoDraw(False)
    



def slide(myWin, list_targets,color, shape, number, aspect,text_tag, starting_pos,ID):
    if number=='singular':
        flipy=0.074
    else:
        flipy=0.06
    timer=core.CountdownTimer(5)
    
    if starting_pos=='left':        
        start_pos=[[-0.4,0.4,0.05],[-0.4,0.4,0.05]]
        polarity=1
    else:
        start_pos=[[0.4,-0.4,-0.05],[0.4,-0.4,-0.05]]
        polarity=-1
        
    target=list_targets[0]
    target1=list_targets[1]
    target2=list_targets[2]
    target3=list_targets[3]
    target4=list_targets[4]
    target5=list_targets[5]
    target6=list_targets[6]
    target7=list_targets[7]
    target8=list_targets[8]
    if aspect=='perfective':
        if number=='singular':            
            target.setAutoDraw(True)            
            for i in np.arange(start_pos[0][0],start_pos[0][1],start_pos[0][2]):
                    target.setPos([i,0])                            
                    myWin.flip()
                    #myWin.getMovieFrame()
                    core.wait(flipy)
            core.wait(5.-flipy*16)
        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)
            for i in np.arange(start_pos[1][0],start_pos[1][1],start_pos[1][2]):                    
                    target1.setPos([(-0.06*polarity)+i,0.15])
                    target4.setPos([(0.3*polarity)+i, -0.2])
                    target6.setPos([(-0.14*polarity)+i, 0])
                    target7.setPos([(0.24*polarity)+i, 0.24])                            
                    target.setPos([i, 0])
                    target2.setPos([(0.06*polarity)+i, -0.18])
                    target3.setPos([(0.1*polarity)+i,0.15])
                    target5.setPos([(0.2*polarity)+i, -0.06])
                    target8.setPos([(-0.1*polarity)+i,-0.15])
#                    for target_item in list_targets:
#                        target_item.setPos([(target_item.pos[0]*polarity)+i, target_item.pos[1]])
                    myWin.flip()
                    #myWin.getMovieFrame()
                    core.wait(flipy)
            core.wait(5.-flipy*16)
    else:
        if number=='singular':
            target.setAutoDraw(True)
            while timer.getTime()>0:
                    
                    for i in np.arange(start_pos[0][0],start_pos[0][1],start_pos[0][2]):
                            pre_draw=timer.getTime()                           
                            target.setPos([i, 0])
                            myWin.flip()
                            #myWin.getMovieFrame()
                            core.wait(flipy)
                            #print pre_draw-timer.getTime()
                    for i in np.arange(-start_pos[0][0]-(0.1*polarity), -start_pos[0][1],-start_pos[0][2]):                            
                            target.setPos([i, 0])
                            myWin.flip()
                            #myWin.getMovieFrame()
                            core.wait(flipy)

        else:
            for item_target in list_targets[:]:
                item_target.setAutoDraw(True)
            while timer.getTime()>0:
                    
                    for i in np.arange(start_pos[1][0],start_pos[1][1],start_pos[1][2]):
                            pre_draw=timer.getTime()
                            target1.setPos([(-0.06*polarity)+i,0.15])
                            target4.setPos([(0.3*polarity)+i, -0.2])
                            target6.setPos([(-0.14*polarity)+i, 0])
                            target7.setPos([(0.24*polarity)+i, 0.24])                            
                            target.setPos([i, 0])
                            target2.setPos([(0.06*polarity)+i, -0.18])
                            target3.setPos([(0.1*polarity)+i,0.15])
                            target5.setPos([(0.2*polarity)+i, -0.06])
                            target8.setPos([(-0.1*polarity)+i,-0.15])
#                            for target_item in list_targets:
#                                target_item.setPos([(target_item.pos[0]*polarity)+i, target_item.pos[1]])
                            myWin.flip()
                            #myWin.getMovieFrame()
                            core.wait(flipy)
                            #print pre_draw-timer.getTime()
                    for i in np.arange(-start_pos[1][0]-(0.1*polarity),-start_pos[1][1],-start_pos[1][2]):
                            target1.setPos([(-0.06*polarity)+i,0.15])
                            target4.setPos([(0.3*polarity)+i, -0.2])
                            target6.setPos([(-0.14*polarity)+i, 0])
                            target7.setPos([(0.24*polarity)+i, 0.24])                            
                            target.setPos([i, 0])
                            target2.setPos([(0.06*polarity)+i, -0.18])
                            target3.setPos([(0.1*polarity)+i,0.15])
                            target5.setPos([(0.2*polarity)+i, -0.06])
                            target8.setPos([(-0.1*polarity)+i,-0.15])
#                            for target_item in target_list:
#                                target_item.setPos([(target_item.pos[0]*polarity)+i, target_item.pos[1]])
                            myWin.flip()
                            #myWin.getMovieFrame()
                            core.wait(flipy)

    for item_target in list_targets:
        item_target.setAutoDraw(False)

size_shapes=[0.08,0.12]
size_shapes_objects=[0.08, 0.12]

def intransitive(myWin, color, shape, number, movement, aspect,part,ID,chain,task,starting_pos,number_trial,number_list,hol_tag,myRole,socket,role):
    if starting_pos=='left':        
        start_pos=-0.4
        polarity=1
    else:
        start_pos=0.4
        polarity=-1
    target=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0*polarity)+start_pos,0])
    target1=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.06*polarity)+start_pos,0.15])
    target2=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.06*polarity)+start_pos,-0.18])
    target3=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.1*polarity)+start_pos,0.15])
    target4=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.3*polarity)+start_pos,-0.2])
    target5=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.2*polarity)+start_pos, -0.06])
    target6=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.24*polarity)+start_pos,0])
    target7=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.24*polarity)+start_pos, 0.24])
    target8=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.2*polarity)+start_pos,-0.15])    
    list_targets=[target,target1,target2,target3,target4,target5,target6, target7,target8]
    text_tag_int=hol_tag
    tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0.55], text=text_tag_int)
    if part=='first_part':
        tag.setAutoDraw(True)
#        tag.setPos([0,0])
        myWin.flip()
        core.wait(2)
#        tag.setPos([0,0.55])
        if movement=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_int,starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect,text_tag_int, starting_pos,ID)

        tag.setAutoDraw(False)
    else:
        if movement=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_int,starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect,text_tag_int,starting_pos,ID)
        for key in event.getKeys():
            if key in ['escape']: 
                myWin.close()
                core.quit()
    if task=='retyping':
        if part=='second_part':
            t='Type now, please.'
        else:
            t='Retype now, please.'
        tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0], text=t)        
        tag.draw()
        myWin.flip()
        allow_typing(myWin, ID,chain, text_tag_int,number_trial,number_list,part,myRole,socket, role)

    
def transitive(myWin, color, color_obj, shape, shape_obj,number, number_obj, movement_trans, aspect, part, ID,chain,task,starting_pos, number_trial,number_list,hol_tag,myRole,socket, role):
    if starting_pos=='right':
        starting_pos_obj= 'left'
    else:
        starting_pos_obj='right'
        
    if number_obj =='singular':
        num_obj=1
    else:
        num_obj=9
    
    if number=='singular':
        plus_pos=0.2
    else:
        plus_pos=0.0        

    if starting_pos=='left':        
        start_pos= -0.4
        polarity=1
    else:
        start_pos=0.4
        polarity=-1
        
    target=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0*polarity)+start_pos,0])
    target1=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.06*polarity)+start_pos,0.15])
    target2=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.06*polarity)+start_pos,-0.18])
    target3=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.1*polarity)+start_pos,0.15])
    target4=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.3*polarity)+start_pos,-0.2])
    target5=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.2*polarity)+start_pos, -0.06])
    target6=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.24*polarity)+start_pos,0])
    target7=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(0.24*polarity)+start_pos, 0.24])
    target8=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape, sf=3, name='target', color='%s'%color, size=size_shapes, pos=[(-0.2*polarity)+start_pos,-0.15])    
    list_targets=[target,target1,target2,target3,target4,target5,target6, target7,target8]
    
    target_object1=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.8-0.1-plus_pos,0.1])
    target_object=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.76-0.1-plus_pos, -0.01])
    target_object2=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.88-0.1-plus_pos, 0.2])
    target_object3=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.73-0.1-plus_pos, -0.15])
    target_object4=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.85-0.1-plus_pos, -0.24])
    target_object5=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.7-0.1-plus_pos, 0.13])
    target_object6=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.76-0.1-plus_pos, 0.25])
    target_object7=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.88-0.1-plus_pos, -0.07])
    target_object8=visual.PatchStim(myWin, units='norm',tex='None', mask='%s'%shape_obj, sf=3, name='target', color='%s'%color_obj, size=size_shapes_objects, pos=[0.9-0.1-plus_pos, 0.07])
    list_targets_obj=[target_object, target_object1, target_object2, target_object3, target_object4, target_object5, target_object6, target_object7, target_object8]
    
    text_tag_trans=hol_tag
    tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0.55], text=text_tag_trans)

            
    if part=='first_part':
        tag.setAutoDraw(True)
#        tag.setPos([0,0])
        myWin.flip()
        core.wait(2)
#        tag.setPos([0,0.55])
        if starting_pos_obj == 'right':
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)
        else:
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)    
                item.setPos([-item.pos[0], -item.pos[1]])
        if movement_trans=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_trans, starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect,text_tag_trans, starting_pos,ID)
        tag.setAutoDraw(False)
    else:
        if starting_pos_obj == 'right':
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)
        else:
            for item in list_targets_obj[:num_obj]:
                item.setAutoDraw(True)    
                item.setPos([-item.pos[0], -item.pos[1]])
        if movement_trans=='bounce':
            bounce(myWin, list_targets,color, shape, number, aspect,text_tag_trans, starting_pos,ID)
        else:
            slide(myWin, list_targets,color, shape, number, aspect, text_tag_trans, starting_pos,ID)
        for key in event.getKeys():
            if key in ['escape']: 
                myWin.close()
                core.quit()
    for item in list_targets_obj[:num_obj]:
        item.setAutoDraw(False)
    if task=='retyping':
        if part=='second_part':
            t='Type now, please.'
        else:
            t='Retype now, please.'
        tag=visual.TextStim(myWin, units='norm', color='black',pos=[0,0], text=t)        
        tag.draw()
        myWin.flip()
        allow_typing(myWin, ID, chain, text_tag_trans,number_trial,number_list,part,myRole,socket,role)
