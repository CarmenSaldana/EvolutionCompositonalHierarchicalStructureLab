from psychopy import gui
from comu_module import *
import random

info = {"Chain":'',"Participant's ID":''}
infoDlg = gui.DlgFromDict(dictionary=info, title='TestExperiment', fixed=['ExpVersion'])
if infoDlg.OK:
    print info        
else: print 'User Cancelled'

ID=info["Participant's ID"]
chain=int(info["Chain"])
ID_minus_one= int(float(ID))-1
ID_iterated_string=str(ID_minus_one)


list_input=random.choice(['server','client'])
lists=t_lists(chain, ID_iterated_string,list_input)
save_test_list(lists,chain,ID)

